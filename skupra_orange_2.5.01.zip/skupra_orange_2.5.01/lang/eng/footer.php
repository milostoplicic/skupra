<?php

if (!defined('PROTECT')){die('Protected Content!');}

$c = array(

	'copy'				=> 'Copyright <b>&copy;</b> 2019, 2020 SkupRa',
	'signin'			=> 'Sign in',
	'signout'			=> 'Sign out',
	'write'				=> 'Write',
	'edit'				=> 'Edit',
	'delete'			=> 'Delete',
	'images'			=> 'Images',
	'add_category'		=> 'Add category',
	'edit_category'		=> 'Edit category',
	'delete_category'	=> 'Delete category',
	'comments'			=> 'Comments'
);

?>