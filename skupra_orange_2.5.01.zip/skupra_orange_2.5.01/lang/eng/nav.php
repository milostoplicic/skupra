<?php

if (!defined('PROTECT')){die('Protected Content!');}

$c = array(

	'intro'			=> 'Intro',
	'blog'			=> 'Blog',
	'categories'	=> 'Categories',
	'archive'		=> 'Archive',
	'manifest'		=> 'Manifest',
	'contact'		=> 'Contact',
	'lang'			=> 'Letter/Lang',
	'cyr'			=> 'СР Ћирилица',
	'lat'			=> 'SR Latinica',
	'eng'			=> 'English'
);

?>