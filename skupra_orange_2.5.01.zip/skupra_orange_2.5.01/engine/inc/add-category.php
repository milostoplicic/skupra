<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (isset($_POST['submit'])) {
	
	$catname = $_POST['catname'];
	$opis = $_POST['opis'];
	$image = $_POST['image'];
	
	if (empty($catname) OR empty($opis) OR empty($_POST['opis_en']) OR empty($_POST['catname_en'])) {
		
		$e = "<p class='red'>$c[fill]</p>";
	} else {
		
		$e = Engine::AddCategory($catname, $opis, $_POST['catname_en'], $_POST['opis_en'], $image);
	}
}

$cont =
"
<div id='cont'>
<h1>$c[addc]</h1>
$e
<form action='' method='post'>
$c[imec]<br>
<input type='text' name='catname' maxlength='64' placeholder='$c[imec2]' class='fil3'><br><br>
$c[opis]<br>
<textarea class='fil2' name='opis' maxlength='200' placeholder='$c[opis2]'></textarea><br><br>
$c[imec_en]<br>
<input type='text' name='catname_en' maxlength='64' placeholder='$c[imec2_en]' class='fil3'><br><br>
$c[opis_en]<br>
<textarea class='fil2' name='opis_en' maxlength='200' placeholder='$c[opis2_en]'></textarea><br><br>
$c[puts]<br>
<input type='text' name='image' maxlength='128' placeholder='$c[puts2]' class='fil3'><br><br>
<input type='submit' name='submit' class='but1' value='$c[pot]'>
</form>
</div>
";

?>