<?php

if (!defined('PROTECT')){die('Protected Content!');}

$intro =
"<center>
<div class='intro'>
<img src='".ROOT."look/img/skupra.png'><br>
<a class='links' href='".ROOT.LANG.'/blog'."'>My Blog</a> <a class='links' href='".ROOT.LANG.'/kontakt'."'>Contact</a>
</div>
</center>
";
?>