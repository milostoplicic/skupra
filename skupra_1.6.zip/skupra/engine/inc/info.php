<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (C2 == 'email-sent') {
	
	$e = "<p class='green'>Порука је успешно послата. Биће вам одговорено у најкраћем року.</p>";
} else if (C2 == 'write-success') {
	
	$e = "<p class='green'>Чланак успешно написан!</p>";
} else if (C2 == 'edit-success') {
	
	$e = "<p class='green'>Чланак успешно едитован!</p>";
} else if (C2 == 'delete-success') {
	
	$e = "<p class='green'>Успешно избрисан чланак!</p>";
} else if (C2 == 'add-category-success') {
	
	$e = "<p class='green'>Успешно креирана категорија!</p>";
} else if (C2 == 'edit-category-success') {
	
	$e = "<p class='green'>Категорија успешно едитована!</p>";
} else if (C2 == 'category-delete-success') {
	
	$e = "<p class='green'>Категорија успешно избрисана!</p>";
} else {
	
	$e = "<p class='red'>Protected Content!</p>";
}

$cont =
"
<div id='cont'>
<h1>Инфо</h1>
$e
</div>
";

?>