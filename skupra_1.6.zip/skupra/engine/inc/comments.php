<?php

if (!defined('PROTECT')){die('Protected Content!');}

$cont =
"
<div id='cont'>
<h1>Коментари</h1>
</div>
";

?>