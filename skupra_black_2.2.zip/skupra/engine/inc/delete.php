<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

$authorid = Engine::AuthorId($_SESSION[SITE]['username']);
	
if (isset($_POST['submit'])) {
	
	$id = $_POST['id'];
	
	$link = new DB();
	
	if (USERTYPE == 1) {
	
		$query = "DELETE FROM articles WHERE artid = ?";
		$result = $link->DeleteRow($query, [$id]);
	} else if (USERTYPE == 2) {
		
		$query = "DELETE FROM articles WHERE artid = ? AND authorid = ?";
		$result = $link->DeleteRow($query, [$id, $authorid]);
	}
	
	if ($result) {
		
		header('Location: '.ROOT.LANG.'/info/delete-success');
	} else {
		
		$e = "<p class='red'>Нема тог чланка!</p>";
	}
}

$s = '';

$link = new DB();

if (USERTYPE == 1) {	
	
	$query1 = "SELECT COUNT(*) FROM articles";
	$count = $link->GetRow($query1);
} else if (USERTYPE == 2) {
	
	$query1 = "SELECT COUNT(*) FROM articles WHERE authorid = ?";
	$count = $link->GetRow($query1, [$authorid]);
}

$total = ($count['COUNT(*)']);

if ($total > 0) {	
	
	$limit = 30;
	$page = (C2 != '') ? C2 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);
	
	if (USERTYPE == 1) {
		
		$query = "SELECT * FROM articles ORDER BY artid DESC LIMIT $start, $limit";
		$result = $link->GetRows($query);
	} else if (USERTYPE == 2) {
		
		$query = "SELECT * FROM articles WHERE authorid = ? ORDER BY artid DESC LIMIT $start, $limit";
		$result = $link->GetRows($query, [$authorid]);
	}
	
	foreach ($result as $r) {
		
		$s .= "<p><b>$r[artid]</b> | $r[header] | $r[seo]</p>";
	}

	$s .=
	"
	<form action='' method='post'>
	Унеси ИД број чланка који желиш да избришеш.<br><br>
	ИД: <input type='text' name='id' class='fil4'>
	<input type='submit' name='submit' class='but1' value='Избриши'>
	</form>
	";

	$s .= Engine::Pagination($page, $num_page, 'izbrisi');
} else {
	
	$s = "<p class='red'>Нема чланака!</p>";
}

if (USERTYPE == 1) {
	
	$ddd = '';
} else if (USERTYPE == 2) {
	
	$ddd = 'свој';
}

$cont =
"
<div id='cont'>
<h1>Избриши $ddd чланак</h1>
$e
$s
</div>
";

?>