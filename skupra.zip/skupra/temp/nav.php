<?php

if (!defined('PROTECT')){die('Protected Content!');}

$nav = 
"
<nav>
	<ul>
	<li><img src='".ROOT."look/img/logo.png'></li>
	  <li><a $b href='".ROOT.LANG."/blog'>Блог</a></li>
	  <li><a $k href='".ROOT.LANG."/kategorije'>Категорије</a></li>
	  <li><a $a href='".ROOT.LANG."/arhiva'>Архива</a></li>
	  <li><a $m href='".ROOT.LANG."/manifest'>Манифест</a></li>
	  	  <li><a $ko href='".ROOT.LANG."/kontakt'>Контакт</a></li>
	  <li class='dropdown'>
		<a href='' class='dropbtn'>Писмо</a>
		<div class='dropdown-content'>
			<a href='".ROOT."cyr/".$c1.$c2.$c3.$c4."'>Ћирилица</a>
			<a href='".ROOT."lat/".$c1.$c2.$c3.$c4."'>Latinica</a>
		</div>
	  </li>
	</ul>
</nav>
";

?>