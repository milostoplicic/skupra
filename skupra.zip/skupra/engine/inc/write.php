<?php

if (!defined('PROTECT')){die('Protected Content!');}

$error = '';

$authorid = Engine::AuthorId($_SESSION[SITE]['username']);

if (isset($_POST['submit'])) {
	
	if (empty($_POST['header']) OR empty($_POST['tekst'])) {
		
		$error = "<p class='red'>Попуните обавезна поља!</p>";
	} else {
		
		$error = Engine::Write($_POST['header'], $_POST['catid'], $_POST['tekst'], $authorid);
	}
}

$selectbox = Engine::SelectBox('');

$cont =
"
<div id='cont'>
<h1>Пиши</h1>
$error
<form action='' method='post'>
Наслов(*):<br>
<input type='text' name='header' class='fil3' maxlength='128'><br><br>
Kategorija(*): 
<select class='selbox1' name='catid'>
$selectbox
</select><br><br>
Текст(*):<br>
<textarea id='edit' name='tekst'></textarea><br><br>
<input type='submit' name='submit' class='but1' value='Потврди'>
</form>
<script src='".ROOT."engine/tinymce/tinymce.min.js'></script>
<script>tinymce.init({
		relative_urls : false,
		remove_script_host : true,
		document_base_url : '".ROOT."',
		content_css : '".ROOT.'look/css/style.css'."',
		  selector: 'textarea',
		  height: 400,
		  theme: 'modern',
		  plugins: [
			'advlist autolink lists link image charmap print preview hr anchor pagebreak',
			'searchreplace wordcount visualblocks visualchars code fullscreen',
			'insertdatetime media nonbreaking save table contextmenu directionality',
			'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
		  ],
		  toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
		  toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
		  image_advtab: true
		 });
		 </script>
</div>
";

?>