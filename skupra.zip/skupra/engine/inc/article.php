<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s = '';

if (C2 != '') {
	
	$link = new DB();
	
	if (!isset($_SESSION[SITE][C2])) {
		
		$query1 = "UPDATE articles SET pregledi = pregledi + 1 WHERE seo = ?";
		$result1 = $link->UpdateRow($query1, [C2]);
	
		$_SESSION[SITE][C2] = 1;
	}
	
	$query = "SELECT * FROM articles WHERE seo = ?";
	$result = $link->GetRow($query, [C2]);
	
	if ($result) {
		
		$date = explode('-', $result['date']);
		$date = $date[2].'.'.$date[1].'.'.$date[0];
		
		$cat = Engine::CatName($result['catid']);
		
		$author = Engine::Author($result['authorid']);
		
		$s .=
		"
		<h2>$result[header]</h2>
		<p class='date'>Датум: <b>$date</b> | Категорија: <b>$cat</b> | Аутор: <b>$author</b> | Прегледи: <b>$result[pregledi]</b></p>
		$result[tekst]
		";
	} else {
		
		$s = "<p>No content!</p>";
	}
} else {
	
	$s = "<p>No content!</p>";
}

$cont =
"
<div id='cont'>
$s
</div>
";

?>