<?php

if (!defined('PROTECT')){die('Protected Content!');}

$c = array(

	'html_lang'		=> 'en',
	'charset'		=> 'utf-8',
	'description'	=> 'My crazy thoughts.',
	'keywords'		=> 'web, internet, blog, milos, development',
	'author'		=> 'Milos Toplicic',
	//
	'blog'			=> 'blog',
	'categories'	=> 'categories',
	'archive'		=> 'archive',
	'manifest'		=> 'manifest',
	'contact'		=> 'contact',
	'signin'		=> 'sign in',
	'signout'		=> 'sign out',
	'write'			=> 'write article',
	'edit'			=> 'edit article',
	'delete'		=> 'delete article',
	'images'		=> 'images',
	'addc'			=> 'add category',
	'editc'			=> 'edit category',
	'deletec'		=> 'delete category',
	'comments'		=> 'comments'
);

?>