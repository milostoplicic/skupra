<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (C2 == 'email-sent') {
	
	$e = "<p class='green'>$c[emsent]</p>";
} else if (C2 == 'write-success') {
	
	$e = "<p class='green'>$c[clanakus]</p>";
} else if (C2 == 'edit-success') {
	
	$e = "<p class='green'>$c[clanaked]</p>";
} else if (C2 == 'delete-success') {
	
	$e = "<p class='green'>$c[usdel]</p>";
} else if (C2 == 'add-category-success') {
	
	$e = "<p class='green'>$c[usdelca]</p>";
} else if (C2 == 'edit-category-success') {
	
	$e = "<p class='green'>$c[catusc]</p>";
} else if (C2 == 'category-delete-success') {
	
	$e = "<p class='green'>$c[catusdel]</p>";
} else {
	
	$e = "<p class='red'>$c[zabranjenos]</p>";
}

$cont =
"
<div id='cont'>
<h1>$c[info]</h1>
$e
</div>
";

?>