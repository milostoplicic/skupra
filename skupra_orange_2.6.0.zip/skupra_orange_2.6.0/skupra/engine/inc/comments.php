<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s = '';

$link = new DB();

if (isset($_POST['submit'])) {

	$comid = $_POST['comid'];

	if (!empty($comid)) {
		
		$query = "UPDATE comments SET pub = 1 WHERE comid = ?";
		$result = $link->UpdateRow($query, [$comid]);
		
		$s .= "<p class='green'>$c[comob]</p>";
	}
}

if (isset($_POST['submit1'])) {

	$comid = $_POST['comid'];

	if (!empty($comid)) {
		
		$query = "UPDATE comments SET pub = 0 WHERE comid = ?";
		$result = $link->UpdateRow($query, [$comid]);

		$s .= "<p class='red'>$c[comuk]</p>";
	}
}

if (isset($_POST['submit2'])) {

	$comid = $_POST['comid'];

	if (!empty($comid)) {
		
		$query = "DELETE FROM comments WHERE comid = ?";
		$result = $link->UpdateRow($query, [$comid]);

		$s .= "<p class='red'>$c[comiz]</p>";
	}
}

$query1 = "SELECT COUNT(*) FROM comments";
$count = $link->GetRow($query1);

$total = ($count['COUNT(*)']);

if ($total > 0) {
	
	$limit = 30;
	$page = (C2 != '') ? C2 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);
	
	$query = "SELECT * FROM comments ORDER BY comid DESC LIMIT $start, $limit";
	$result = $link->GetRows($query);

	foreach ($result as $r) {
		
		if ($r['pub'] == 0) {

			$e = "<span class='red'>$c[comnipri]</span>";
		} else {

			$e = "<span class='green'>$c[compri]</span>";
		}

		$s.= "<p><b>$r[comid]</b> | <b>$r[name]</b><br>$r[comment] | $e</p>";
	}
	
	$s .=
	"
	<form action='' method='post'>
	$c[unid]<br><br>
	$c[id] <input type='text' name='comid' class='fil4'>
	<input type='submit' name='submit' class='but1' value='$c[ob]'>
	</form>
	<br>
	<form action='' method='post'>
	$c[obid]<br><br>
	$c[id] <input type='text' name='comid' class='fil4'>
	<input type='submit' name='submit1' class='but1' value='$c[ukloni]'>
	</form>
	<div class='line'></div>
	<h2>$c[izbco]</h2>
	<form action='' method='post'>
	$c[izbri]<br><br>
	$c[id] <input type='text' name='comid' class='fil4'>
	<input type='submit' name='submit2' class='but1' value='$c[izb]'>
	</form>
	";

	$s .= Engine::Pagination($page, $num_page, 'komentari');
} else {

	$s = "<p class='red'>$c[noco]</p>";
}

$cont =
"
<div id='cont'>
<h1>$c[comen2]</h1>
$s
</div>
";

?>