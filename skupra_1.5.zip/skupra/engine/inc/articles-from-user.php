<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s = '';

$link = new DB();

$authorid = Engine::AuthorId(C2);

$query1 = "SELECT COUNT(*) FROM articles WHERE authorid = ?";
$count = $link->GetRow($query1, [$authorid]);

$total = ($count['COUNT(*)']);

if ($total > 0) {
	
	$limit = 30;
	$page = (C3 != '') ? C3 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);
	
	$query = "SELECT * FROM articles WHERE authorid = ? ORDER BY artid DESC LIMIT $start, $limit";
	$result = $link->GetRows($query, [$authorid]);

	foreach ($result as $r) {
		
		$date = explode('-', $r['date']);
		$date = $date[2].'.'.$date[1].'.'.$date[0];
		
		$string = mb_substr(strip_tags($r['tekst'], '<img>'), 0, $r['minview'], 'utf-8');
		
		$cat = Engine::CatName($r['catid']);

		$catseo = Engine::CatSeo($r['catid']);
		
		$author = Engine::Author($r['authorid']);
		
		$s .= 
		"
		<h2><a href='".ROOT.LANG."/clanak/".$r['seo']."'>$r[header]</a></h2>
		<p class='date'>Датум: <b>$date</b> | Категорија: <a href='".ROOT.LANG."/kategorija/".$catseo."'><b>$cat</b></a> | Аутор: <b>$author</b> | Прегледи: <b>$r[pregledi]</b></p>
		<p>".$string." ... <a href='".ROOT.LANG."/clanak/".$r['seo']."'>Прочитај више</a></p>
		<div class='line'></div>
		";
	}
	
	$s .= Engine::Pagination($page, $num_page, 'clanci-od-korisnika/'.C2);
} else {
	
	$s = "<p class='red'>Нема чланака!</p>";
}

$cont =
"
<div id='cont'>
<h1>Чланци од корисника: ".C2."</h1>
$s
</div>
";

?>