<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s = '';

$link = new DB();
	
$query1 = "SELECT COUNT(*) FROM articles WHERE year(date) = ? AND month(date) = ?";
$count = $link->GetRow($query1, [C2, C3]);

$total = ($count['COUNT(*)']);

if ($total > 0) {
	
	$limit = 30;
	$page = (C4 != '') ? C4 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);
	
	$query = "SELECT * FROM articles WHERE year(date) = ? AND month(date) = ? ORDER BY artid DESC LIMIT $start, $limit";
	$result = $link->GetRows($query, [C2, C3]);

	foreach ($result as $r) {
		
		$date = explode('-', $r['date']);
		$date = $date[2].'.'.$date[1].'.'.$date[0];
		
		$string = mb_substr(strip_tags($r['tekst'], '<img>'), 0, $r['minview'], 'utf-8');
		
		$cat = Engine::CatName($r['catid']);

		$catseo = Engine::CatSeo($r['catid']);
		
		$author = Engine::Author($r['authorid']);
		
		$s .= 
		"
		<h2><a href='".ROOT.LANG."/clanak/".$r['seo']."'>$r[header]</a></h2>
		<p class='date'>Датум: <b>$date</b> | Категорија: <a href='".ROOT.LANG."/kategorija/".$catseo."'><b>$cat</b></a> | Аутор: <a href='".ROOT.LANG."/clanci-od-korisnika/".$author."'><b>$author</b></a> | Прегледи: <b>$r[pregledi]</b></p>
		<p>".$string." ... <a href='".ROOT.LANG."/clanak/".$r['seo']."'>Прочитај више</a></p>
		<div class='line'></div>
		";
	}
	
	$s .= Engine::Pagination($page, $num_page, 'arhiva-za/'.C2.'/'.C3);
} else {
	
	$s = "<p class='red'>Нема чланака!</p>";
}

$cont =
"
<div id='cont'>
<h1>Архива за: ".C2.'/'.C3."</h1>
$s
</div>
";

?>