<?php

if (!defined('PROTECT')){die('Protected Content!');}

class Content {
	
	public function __construct() {

		require_once 'temp/site.php';
	}

	static public function Body() {
	
		return self::Nav().self::Cont().self::Footer();
	}

	static private function Cont() {
		
		if (USERTYPE == 0) {
			
			if (C1 == HOME OR C1 == '') {
			
				require_once 'engine/inc/'.HOME.'.php';
			} else if (C1 == 'blog') {
				
				require_once 'engine/inc/blog.php';
			} else if (C1 == 'kategorije') {
				
				require_once 'engine/inc/categories.php';
			} else if (C1 == 'arhiva') {
				
				require_once 'engine/inc/archive.php';
			} else if (C1 == 'manifest') {
				
				require_once 'engine/inc/manifest.php';
			} else if (C1 == 'kontakt') {
				
				require_once 'engine/inc/contact.php';
			} else if (C1 == 'prijavi-se') {
				
				require_once 'engine/inc/signin.php';
			} else if (C1 == 'clanak') {
				
				require_once 'engine/inc/article.php';
			} else if (C1 == 'arhiva-za') {
				
				require_once 'engine/inc/archive-for.php';
			} else if (C1 == 'kategorija') {
				
				require_once 'engine/inc/category.php';
			} else if (C1 == 'clanci-od-korisnika') {

				require_once 'engine/inc/articles-from-user.php';
			} else {
				
				require_once 'engine/inc/info.php';
			}
		} else if (USERTYPE == 1) {
			
			if (C1 == HOME OR C1 == '') {
			
				require_once 'engine/inc/'.HOME.'.php';
			} else if (C1 == 'blog') {
				
				require_once 'engine/inc/blog.php';
			} else if (C1 == 'kategorije') {
				
				require_once 'engine/inc/categories.php';
			} else if (C1 == 'arhiva') {
				
				require_once 'engine/inc/archive.php';
			} else if (C1 == 'manifest') {
				
				require_once 'engine/inc/manifest.php';
			} else if (C1 == 'kontakt') {
				
				require_once 'engine/inc/contact.php';
			} else if (C1 == 'odjavi-se') {
				
				require_once 'engine/inc/logout.php';
			} else if (C1 == 'pisi') {
				
				require_once 'engine/inc/write.php';
			} else if (C1 == 'edituj') {
				
				require_once 'engine/inc/edit.php';
			} else if (C1 == 'izbrisi') {
				
				require_once 'engine/inc/delete.php';
			} else if (C1 == 'slike') {
				
				require_once 'engine/inc/images.php';
			} else if (C1 == 'dodaj-kategoriju') {
				
				require_once 'engine/inc/add-category.php';
			} else if (C1 == 'edituj-kategoriju') {
				
				require_once 'engine/inc/edit-category.php';
			} else if (C1 == 'izbrisi-kategoriju') {
				
				require_once 'engine/inc/delete-category.php';
			} else if (C1 == 'clanak') {
				
				require_once 'engine/inc/article.php';
			} else if (C1 == 'kategorija') {
				
				require_once 'engine/inc/category.php';
			} else if (C1 == 'arhiva-za') {
				
				require_once 'engine/inc/archive-for.php';
			} else if (C1 == 'clanci-od-korisnika') {

				require_once 'engine/inc/articles-from-user.php';
			} else {
				
				require_once 'engine/inc/info.php';
			}
		} else if (USERTYPE == 2) {
			
			if (C1 == HOME OR C1 == '') {
			
				require_once 'engine/inc/'.HOME.'.php';
			} else if (C1 == 'blog') {
				
				require_once 'engine/inc/blog.php';
			} else if (C1 == 'kategorije') {
				
				require_once 'engine/inc/categories.php';
			} else if (C1 == 'arhiva') {
				
				require_once 'engine/inc/archive.php';
			} else if (C1 == 'manifest') {
				
				require_once 'engine/inc/manifest.php';
			} else if (C1 == 'kontakt') {
				
				require_once 'engine/inc/contact.php';
			} else if (C1 == 'odjavi-se') {
				
				require_once 'engine/inc/logout.php';
			} else if (C1 == 'pisi') {
				
				require_once 'engine/inc/write.php';
			} else if (C1 == 'edituj') {
				
				require_once 'engine/inc/edit.php';
			} else if (C1 == 'izbrisi') {
				
				require_once 'engine/inc/delete.php';
			} else if (C1 == 'slike') {
				
				require_once 'engine/inc/images.php';
			} else if (C1 == 'dodaj-kategoriju') {
				
				require_once 'engine/inc/add-category.php';
			} else if (C1 == 'edituj-kategoriju') {
				
				require_once 'engine/inc/edit-category.php';
			} else if (C1 == 'izbrisi-kategoriju') {
				
				require_once 'engine/inc/delete-category.php';
			} else if (C1 == 'clanak') {
				
				require_once 'engine/inc/article.php';
			} else if (C1 == 'kategorija') {
				
				require_once 'engine/inc/category.php';
			} else if (C1 == 'arhiva-za') {
				
				require_once 'engine/inc/archive-for.php';
			} else if (C1 == 'clanci-od-korisnika') {

				require_once 'engine/inc/articles-from-user.php';
			} else {
				
				require_once 'engine/inc/info.php';
			}
		}
		
		return $cont;
	}
	
	static private function Nav() {
		
		if (C1 == '') {$c1 = '';} else {$c1 = C1.'/';}
		if (C2 == '') {$c2 = '';} else {$c2 = C2.'/';}
		if (C3 == '') {$c3 = '';} else {$c3 = C3.'/';}
		if (C4 == '') {$c4 = '';} else {$c4 = C4.'/';}
		
		$b = '';
		$k = '';
		$a = '';
		$m = '';
		$ko = '';
		
		if (C1 == '' OR C1 == 'blog') {
			$b = "class='active'";
		} else if (C1 == 'kategorije') {
			$k = "class='active'";
		} else if (C1 == 'arhiva') {
			$a = "class='active'";
		} else if (C1 == 'manifest') {
			$m = "class='active'";
		} else if (C1 == 'kontakt') {
			$ko = "class='active'";
		}
		
		require_once 'temp/nav.php';
		
		return $nav;
	}
	
	static private function Footer() {
		
		require_once 'temp/footer.php';
		
		return $footer;
	}
}

?>