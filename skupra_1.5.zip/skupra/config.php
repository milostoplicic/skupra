<?php

if (!defined('PROTECT')){die('Protected Content!');}

define('SITE', 'skupra'); // Ime kolačića
define('ROOT', '/skupra/'); // Ovo je folder na hostingu, ako je root, ostavite samo kosu crtu. Meni je folder "skupra" i zato piše tako
define('DFLANG', 'cyr'); // ili "lat"
define('COMPRESS', 1); // Ako nećete kompresiju onda stavite "0"

define('HOME', 'blog'); // može nekoliko stranica
define('TITLE', 'Скупра'); // Naslov

define('FAVICON', ROOT.'look/img/favicon-skupra.png');
define('STYLE', ROOT.'look/css/style.css');

define('HOST', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', 'hop99');
define('DBNAME', 'skupra');

define('EMAIL', 'milos@localhost.com');

function Path() {

	$path = isset($_GET['path']) ? $_GET['path'] : '';
	$path = explode ('/', $path);

	return $path;
}

$path = Path();

if ($path[0] == 'cyr') {

	define('LANG', 'cyr');
} else if ($path[0] == 'lat') {
	
	define('LANG', 'lat');
} else {
	
	define('LANG', DFLANG);
}

define('C1', isset($path[1]) ? $path[1] : '');
define('C2', isset($path[2]) ? $path[2] : '');
define('C3', isset($path[3]) ? $path[3] : '');
define('C4', isset($path[4]) ? $path[4] : '');

?>