<?php

ini_set('display_errors', 0);
error_reporting(0);

define('PROTECT', 'skupra');

require_once 'config.php';
require_once 'engine/DB.class.php';
require_once 'engine/Init.class.php';
require_once 'engine/Content.class.php';
require_once 'engine/Decode.class.php';
require_once 'engine/Engine.class.php';

$init = new Init;
$init->Start();

$content = new Content();

$decode = new Decode;
echo $decode->Output();

?>