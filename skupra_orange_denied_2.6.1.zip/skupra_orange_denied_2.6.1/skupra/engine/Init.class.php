<?php

if (!defined('PROTECT')){die('Protected Content!');}

class Init {
	
	public function Start() {
		
		if (isset($_COOKIE[SITE])) {
			
			if (isset($_SESSION[SITE])) {
				
				// ok
			} else {
				
				$data = self::DataFromCookie($_COOKIE[SITE]);
				
				if ($data == false) {
					
					die('Bad cookie! Delete your browser cache and restart');
				} else {
					
					$_SESSION[SITE] = array(
					
						'username'		=> $data['username'],
						'session'		=> $data['session'],
						'usertype'		=> $data['usertype']
					);
				}
			}
		} else {
			if (isset($_SESSION[SITE])) {
				
				// ok
			} else {
				
				$_SESSION[SITE] = array(
				
					'username'		=> '',
					'session'		=> md5(microtime()),
					'usertype'		=> 0
				);
			}
		}
	}
	
	private static function DataFromCookie($session) {

		$link = new DB();

		$query = "SELECT * FROM users WHERE session = ?";
		$result = $link->GetRow($query, [$session]);

		if ($result) {

			return $result;
		} else {

			return false;
		}
	}
}

?>