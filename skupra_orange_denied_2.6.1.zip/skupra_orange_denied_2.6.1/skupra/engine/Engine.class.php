<?php

if (!defined('PROTECT')){die('Protected Content!');}

class Engine {
	
	public static function Signin($username, $password, $remember) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		$query = "SELECT * FROM users WHERE username = ? AND password = ?";
		$result = $link->GetRow($query, [$username, $password]);
		
		if ($result) {
			
			$_SESSION[SITE] = array(
			
				'username'		=> $result['username'],
				'session'		=> $result['session'],
				'usertype'		=> $result['usertype']
			);
			
			if ($remember == 1) {
				
				setcookie(SITE, $result['session'], time()+3600*24*30, '/');
			}
			
			header('Location: '.ROOT.LANG.'/blog');
		} else {
			
			return "<p class='red'>$c[nouser]</p>";
		}
	}
	
	public static function Contact($email, $message) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
			return "<p class='red'>$c[nevem]</p>";
		} else {
			
			mail(EMAIL, 'Message from site SkupRa', $message."\n\n$email", 'From:'.$email);
			
			header('Location: '.ROOT.LANG.'/info/email-sent');
		}
	}
	
	public static function SelectBox($catid) {

		$link = new DB();

		$query = "SELECT * FROM categories";
		$result = $link->GetRows($query);

		$output = '';

		foreach ($result as $cat) {

			if ($catid != '') {
				if ($cat['catid'] == $catid) {
					
					$selected = 'selected';
				} else {
					
					$selected = '';
				}
			} else {
				
				$selected = '';
			}
			
			$output .= "<option value='$cat[catid]' $selected>$cat[catname]</option>";
		}

		return $output;
	}
	
	public static function Write($engleski, $header, $header_en, $catid, $text, $text_en, $authorid, $minview, $comments) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$seo = self::SEO($header);
		
		$date = date("Y-m-d");
		
		$dateseo = date("d-m-Y");
		$seo = $seo.'-'.$dateseo;
		
		$link = new DB();
		$query = "SELECT * FROM articles WHERE seo = ?";
		$result = $link->GetRow($query, [$seo]);
		
		if ($result) {
			
			return "<p class='red'>$c[promese]</p>";
		} else {
			
			$query = "INSERT INTO articles(engleski, header, header_en, seo, date, catid, tekst, tekst_en, pregledi, authorid, minview, comments) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$result = $link->InsertRow($query, [$engleski, $header, $header_en, $seo, $date, $catid, $text, $text_en, 0, $authorid, $minview, $comments]);
			
			header('Location: '.ROOT.LANG.'/info/write-success');
		}
	}
	
	private static function SEO($input) {

		$cir = array (
			
			"А" => "a", "Б" => "b", "В" => "v", "Г" => "g", "Д" => "d", "Ђ" => "dj", "Е" => "e", "Ж" => "z", "З" => "z", "И" => "i", 
			"Ј" => "j", "К" => "k", "Л" => "l", "Љ" => "lj", "М" => "m", "Н" => "n", "Њ" => "nj", "О" => "o", "П" => "p", "Р" => "r", 
			"С" => "s", "Т" => "t", "Ћ" => "c", "У" => "u", "Ф" => "f", "Х" => "h", "Ц" => "c", "Ч" => "c", "Џ" => "dz", "Ш" => "s", 

			"а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "ђ" => "dj", "е" => "e", "ж" => "z", "з" => "z", "и" => "i", 
			"ј" => "j", "к" => "k", "л" => "l", "љ" => "lj", "м" => "m", "н" => "n", "њ" => "nj", "о" => "o", "п" => "p", "р" => "r", 
			"с" => "s", "т" => "t", "ћ" => "c", "у" => "u", "ф" => "f", "х" => "h", "ц" => "c", "ч" => "c", "џ" => "dz", "ш" => "s",
			
			"Š" => "s", "Đ" => "dj", "Č" => "c", "Ć" => "c", "Ž" => "z",
			"š" => "s", "đ" => "dj", "č" => "c", "ć" => "c", "ž" => "z"
		);

		$output = strtr($input, $cir);
		$output = strtolower($output);
		$output = preg_replace("/[\s]/", "-", $output);
		$output = preg_replace("/[^a-z0-9-_]/",'',$output);

		return $output;
	}
	
	public static function Pagination($page, $num_page, $folder) {

		$pag1 = "<div id='pagi'>";
		$pag2 = '';

		for($i = 1; $i <= $num_page; $i++) {
			
			if($i==$page) {
				
				$pag2 .= "&nbsp;".$i."&nbsp;";
			} else {
				
				$pag2 .= "&nbsp;<a href='".ROOT.LANG.'/'.$folder.'/'.$i."'>".$i."</a>&nbsp;";
			}
		}
		
		$pag3 = '</div>';

		return $pag1.$pag2.$pag3;
	}
	
	public static function Edit($engleski, $header_en, $tekst_en, $artid, $header, $seo, $oldseo, $catid, $tekst, $minview, $comments) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$seo = self::SEO($seo);
		
		if ($seo == $oldseo) {

			$query = "UPDATE articles SET engleski = ?, header_en = ?, tekst_en = ?, header = ?, catid = ?, tekst = ?, minview = ?, comments = ? WHERE artid = ?";
			$result = $link->UpdateRow($query, [$engleski, $header_en, $tekst_en, $header, $catid, $tekst, $minview, $comments, $artid]);
		} else {

			$query = "SELECT * FROM articles WHERE seo = ?";
			$result = $link->GetRow($query, [$seo]);

			if ($result) {

				return "<p class='red'>".$c['prose']."</p>";
			} else {

				$query = "UPDATE articles SET engleski = ?, header_en = ?, tekst_en = ?, header = ?, seo = ?, catid = ?, tekst = ?, minview = ?, comments = ? WHERE artid = ?";
				$result = $link->UpdateRow($query, [$engleski, $header_en, $tekst_en, $header, $seo, $catid, $tekst, $minview, $comments, $artid]);
			}
		}

		if ($result) {
			
			header('Location: '.ROOT.LANG.'/info/edit-success');
		}
	}
	
	public static function AddCategory($catname, $opis, $catname_en, $opis_en, $image) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$catseo = self::SEO($catname);
		
		$link = new DB();
		$query = "SELECT * FROM categories WHERE catseo = ?";
		$result = $link->GetRow($query, [$catseo]);
		
		if ($result) {
			
			return "<p class='red'>$c[catex]</p>";
		} else {
			
			$query = "INSERT INTO categories (catname, catname_en, catdesc_en, catseo, catdesc, image) VALUES (?, ?, ?, ?, ?, ?)";
			$result = $link->InsertRow($query, [$catname, $catname_en, $opis_en, $catseo, $opis, $image]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/add-category-success');
			}
		}
	}
	
	public static function EditCategory($catid, $catname, $oldcatname, $opis, $image, $catname_en, $opis_en) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$catseo = self::SEO($catname);
		$oldcatseo = self::SEO($oldcatname);
		
		$link = new DB();
		
		if ($catseo == $oldcatseo) {
			
			$query = "UPDATE categories SET catname = ?, catdesc = ?, image = ?, catname_en = ?, catdesc_en = ? WHERE catid = ?";
			$result = $link->UpdateRow($query, [$catname, $opis, $image, $catname_en, $opis_en, $catid]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/edit-category-success');
			}
		} else {
			
			$query = "SELECT * FROM categories WHERE catseo = ?";
			$result = $link->GetRow($query, [$catseo]);
			
			if ($result) {
				
				return "<p class='red'>$c[catexe]</p>";
			} else {
				
				$query = "UPDATE categories SET catname = ?, catseo = ?, catdesc = ?, image = ?, catname_en = ?, catdesc_en = ? WHERE catid = ?";
				$result = $link->UpdateRow($query, [$catname, $catseo, $opis, $image, $catname_en, $opis_en, $catid]);
				
				if ($result) {
				
					header('Location: '.ROOT.LANG.'/info/edit-category-success');
				}
			}
		}
	}
	
	public static function CatName($catid, $engleski) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		if ($engleski == 0) {

			$query = "SELECT catname FROM categories WHERE catid = ?";

			$result = $link->GetRow($query, [$catid]);
		
			if ($result) {
				
				return $result['catname'];
			} else {
				
				return $c['nocat'];
			}
		} else {

			$query = "SELECT catname_en FROM categories WHERE catid = ?";

			$result = $link->GetRow($query, [$catid]);
		
			if ($result) {
				
				return $result['catname_en'];
			} else {
				
				return $c['nocat'];
			}
		}
	}
	
	public static function CatId($catseo) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT catid FROM categories WHERE catseo = ?";
		$result = $link->GetRow($query, [$catseo]);
		
		if ($result) {
			
			return $result['catid'];
		} else {
			
			return $c['nocat'];
		}
	}
	
	public static function AuthorId($username) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT userid FROM users WHERE username = ?";
		$result = $link->GetRow($query, [$username]);
		
		if ($result) {
			
			return $result['userid'];
		} else {
			
			return $c['noauthor'];
		}
	}
	
	public static function Author($userid) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT username FROM users WHERE userid = ?";
		$result = $link->GetRow($query, [$userid]);
		
		if ($result) {
			
			return $result['username'];
		} else {
			
			return $c['noauthor'];
		}
	}

	public static function CatSeo($catid) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT catseo FROM categories WHERE catid = ?";
		$result = $link->GetRow($query, [$catid]);
		
		if ($result) {
			
			return $result['catseo'];
		} else {
			
			return $c['nocat'];
		}
	}

	public static function Email($email) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
			return "<p class='red'>$c[nevem]</p>";
		} else {

			$link = new DB();
			$query = "SELECT * FROM users WHERE email = ?";
			$result = $link->GetRow($query, [$email]);

			if ($result) {

				if ($result['activ'] == 0) {

					header('Location: '.ROOT.LANG.'/info/activation');
				} else {
					
					$_SESSION[SITE] = array(
			
						'username'		=> $result['username'],
						'session'		=> $result['session'],
						'usertype'		=> 1
					);
				
					setcookie(SITE, $result['session'], time()+3600*24*30, '/');
			
					header('Location: '.ROOT.LANG.'/blog');
				}
			} else {

				$username = explode('@', $email);
				$username = $username[0];

				$session = md5($email);
				$usertype = 1;

				$query = "INSERT INTO users (username, email, session, usertype) VALUES (?, ?, ?, ?)";
				$result = $link->InsertRow($query, [$username, $email, $session, $usertype]);
				
				$to = $email;

				$subject = ':: SkupRa';

				$headers = "From: office@skupra.com\r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
				
				$txt =
				"<style>
					a {
						color: darkorange;
						text-decoration: none;
					}
					a:hover {
						color: #ccc;
					}
				</style>
				<center><img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAP8AAABWCAYAAAAAG0DsAAAABGdBTUEAAK/INwWK6QAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAABjsSURBVHhe7d0J3G7V9MDxfSulhCQZMiUyZIyEiiRpMJMy5maKMg+FyDwVoQEfH9OtZBYqQ2UoQ2TOWBmKSIlovqX773v+5+TxdM4+ez/DO9xn//qcz+097/OeYe+11l5r7bX3s2TF1YRCoTBzrFL/WygUZoyi/IXCjFKUv1CYUYryFwozSlH+QmFGKcpfKMwoRfkLhRllTuf5ly9fHk499dTwi1/8Ipx++unhnHPOCX//+9/DJZdcEv7zn/+Eyy+/PFzveterPz1ZLrvssrDtttuG17zmNfWZwmLjU5/6VPjrX/8aVl111frM5KEOa6yxRrjVrW4V7nznO4fb3va29W9WPqau/JTuYx/7WPjMZz4T/vCHP1RKfp3rXCesttpqYZVVVqmOJUuWVJ/177Qe51//+lc48MADw2Me85j6TGGxcbOb3Szc4AY3uEZepgUZJKeONddcM2y22WZh9913D1tvvXX9iZWDqSn/2WefHfbdd9/wla98JVz/+tevGpHCT7vjuuBl/OpXv6qEp7D4+PGPfxwe97jHhRvf+Mb1melDNRw81osuuqiSnXe9612VB7kyMJWY/0UvelG4733vG0455ZRwi1vcomo0o/18Kf5VV11VPUNR/MXLF7/4xXDd6163/mluIK88U/ddb731qnBjt912C8961rPqTyxuJjryi+Mf/ehHV+6S2H2+lH0YoccDH/jAcOihh9ZnCosNg4kRmPc43/z73/+ucgFf+9rX6jOLk4mN/F/96lfDVlttVY3wa6+99oJRfBCaLbbYov6psNj485//HM4999ypJvpy4EGeeeaZ4clPfnJ9ZnEyEeU/5phjwtKlSysXfyFY5mEuvfTSlS5ZM0sce+yxYfXVV19QA4o81oknnhi+/OUv12cWH2O7/d/97nfDzjvvHG5605tW8dFCo8na/vznP6/PFBYbj3rUo6qZIgZgIXHllVdWBuknP/lJfWZxMZbymz67293uViVDFqLiQ+3APe5xj3D44YfXZwqLCQq20UYbVTKWM/IL9S6++OL6p27I7VprrVWFq7lQHXUqX/jCF8I973nP+uziYSzlF0dfeOGFC84iD+L5XvrSl4ZnP/vZ9ZnCYuJLX/pSePGLXxzWWWed+kw/FH+TTTYJL3/5y6MGgOJL3pm+E8OPMhtEvp7//OeHvfbaqz6zeBhZ+Q844IDw/ve/P9zwhjecSCw2hg2Kcv7551dxmWqtwuLDtNr3vve9rGm+Cy64oFLoRz7ykfWZfp773OeGb37zm9kVpvJJD33oQ8O73/3u+sziYSTll3m9z33uE25yk5uMpfhuza0zFcdam4+fpBFwPddX4FNYnJhSW3fddZPDSvLzj3/8oyroUliWw93vfvdqRiFnVoHsbrnlltVAuNgYSfl32mmncNZZZ1U10HCJXCNAKeUM7nSnO1Ult0KIu9zlLhPxIgorBz/84Q+rZHJOVZ9BZIMNNhgpC//Od74zfPCDH6ymqlNZzMqfnaVTrmtxDsWnwP/85z8r5c+xIf7O511LJ4nHxWhF8QuDjFLVJ8Gb4+4P8oAHPCBcccUV9U9p8C5vdKMb1T8tLrKV/2Uve1nlhnGtZEk///nPh/vf//6VxU2B0hvxv/71r4c73vGO9dlC4dooHGu8yxTIFuXfcccd6zN5SFznDGKg/BYcLUay3P73vve91co4vOlNb7qmwule97pX9W9KrCRBst12211znYWCxKVsb5f3oZM9e1+l2SGHHFItG+5yHRlJrqLkUjM9xK1lSLvu7fNWlimmSsG1H/GIR0RHJN0uGfqb3/wm3PrWt67Phmr1mtF2El7YbW5zm2qaVUIsdyrYwjChoLZJfRb1HD5rEdAoHH300dW6lJyZBcnF/ffff2KrRcnYm9/85upZzjvvvF6dMlsh+f7MZz6zPpNOsvIT2jvc4Q5VZdO3vvWta+IwN7/rXe+anPzTWAcffHDYfvvt6zPzjxpt2d5YpxtRGLnDDjusPnNt3v72t4eDDjqoKnhqQ8dSLNnrZkT7zne+E57ylKdU3lQXPKV3vOMd4bGPfWx9Js5LXvKSKqSKJbyEXgyU+zecdNJJYZdddpmYG0sZudFkhwF4y1vekjxKiqENEOQtFftCUELKMwra+CMf+Uhyxp/q8ICFrnJX4/Lxj3887L333tX99V2KwaR/r3/968OTnvSk+kw6yeZ42bJllfB+//vf/58EzN/+9rfqIVOts8+lfnauUKTRjHZdh9E3Zt1f+cpXhve9732V4g//LSwJVf5sVBp0Zd1bRw//TXOA4TGSpyKkco+26zVH2zXF2Ayg55nEwbgwJOuvv34lN2aIPvGJT9R3i8PLyXH5QT5z2mkYBjOnZoXyk/1JKD5v8RWveEU1iGo3I35bv7Udo5Ks/NwKLu+wVWR5ch6Ae2sOdiFh5I8Jmk42gnUJFq+BULe5qP6Wt0Pwjz/++Prsf+kTciO0GoXUCrTf/va31f36Rg2jpPXxgxD+XIVLQZswBowAr6TPAGhruz3lVN0Jy3C/+92v+jcXYYYS4py1Kfpm4403rn8aHYrPo5zrEvmx78RKJUYOFTrUNOEOO+wQfve739Vn54+f/exnVSfGDJjfs+5twshlP+644yq3vU3xlX9SsiOOOKI++19OO+20qgIt1uF9HscwTYY89j7ccfkNYVyDvhBe5Mxx5+I9uf0qLnlCXTBCzciXitBim222qX/K5w1veEM079IG78m09zh87nOfCx/+8IezchuTYmzl15msbo4B4D2wtA95yEOqpJfEjhkDnedcc/hZ5lY8o8STx2CFl7+dFMpH+5SFArbF28794Ac/qFzl4b/XHkIisyNiyTZSFJVxsLAlFfFn3+jdxOCDHHXUUZXw98FjYCTaDs/aJwcMgDg+VhHXhGE56KOHP/zh9U95WPSl3XLvyYCpQxgVz6w0uAkV55qRy3sHGaUyCm7taFw2tD2O3zuMWEZhB4V7whOeUMXa4zQcoyNW7HL3PA8lVnAymKx68IMfXG0m2ZbV96wMFIseGxlcQ8Koy731ngTy5JNPrs/EEYKpl+Bex9rEPT/0oQ9V92940IMeVIULMVeb4hN2CV7PNoi+//3vfx8+8IEPtHpBg/S914YbbljlClJdYH3UzFzkKjBMOTN8OfIrNLHY6IQTTqjP5KMtf/3rX4/0zA36/HWve910E34xxD3DwpACAdHBFK85CN/wYSRrEkiUvnGRbAxql1W7uo7CX/7yl97dYBkc9xhUfLvKMAhtik8oFD7JI8QUnwL2xZjcyoc97GH1T/0YvbVTTPEYJvccVHxKb2FL7FkomM/JLBPaJz7xif9zMMT77LNPlbGmiG1GvEF7a782fvSjH1X/pio+tLnq0FGUiPGX5MsduCidacFRMR0rCRrz0sieY1pMRPm5kAR1riDcOov7aJTTCebXczGXquNjyuK9mmlJBu7e9753NQK2ucg+SxBNmZnfjiHRx7B13Zvy8EhyXP6UijjP19RlNHB5Y88Cf+fd+6BMPEGfj9Gl3E0YlsOosbe8k3AlN8lJDngm48wsSHzGPCRKT76VKk/LAExE+Vl9HRCz9tOCEN385jev5pCVHedAAfsEjaIrZtIB9i4QLw//jff2OSOn+PGWt7xl/Ztu+hTVNeVGNt100/pMPzZWocQxxJnD5a8pMXbb33XBM4opf0xOGOQcZXQtyvi0pz2tPtOPbeQZZ4nnlDzHIO7HAxrn+x/UL1gKHPO0GKVXvepVlQEYDIsnyURifsz3biuMj1iRUqVAYG53u9tFi5MoPKUwMhJoLvWwcmk+HelastSpWK0Wy/BStpwFI02hUl9Vn3Djpz/9aVXR2CBsE8J0jcb+zjSvvxus8ehCDCoU61IsbS984/oOYq8+75yT+fZslMMGrQzOsDi7jjBEX/7xj3+swjzP5X1zXX0w/hJ0ZnhGQb+SUzUfXe+ofRhAYYEk5p/+9KdOoz7vMT9e8IIXVBZxvmB0FND0uZsNFLrP5QfXTFhDYNoUX3xvQUiO4hMcghe7NyHJcStTXH5CJX8xqPjf+MY3qvOxGJviENgUxYc5+tiopo/a9ldoRv1UxYfPenaJN3vqCbkGD+cs7zWt6j3kbkxzjqL4+tvU7ZFHHlmfyUe9TJ9xY6ya8vdhYzZJJqb8puYIiFFwmg/chcaknKn7qaW4ugREUpDQDAuzdzQaKof96Ec/Wp9Nw2KoPpffCJMTxyq57vO6eEfDrrsYm0cTgyESH6fi+xpi4Qfl50kNYxo3N/6GvteeXYdrapvG4MYUrwt9Qin322+/Kss/CmaMGKPYO+p3sykGlGkzMeUHARSjUgrJKkozl4aAgnIdUzD6pggagRkeFbmZ3vHVr351eOtb31qfTafv3pQjZ084uQ5GNzZ6Q15iuF5BuBAzGvovxwux+IvCdeF66gGG5+S9s3xJzGjMF80zU8jnPOc59dl8nve850WTfO4jLJurvQEmqvzgEnHBFOhwJ61MagpAmmy48xRo0oZBo1KCPswvj+L2wTNz/cxn77HHHvXZdMTN3j82+lC2nKq+lCk+hpi7KzfRYF5ce8XaQj/5O6NRH9qFuypR2fUs3l2OQa5lEKM+4x17h/mC3BrtTWOOitkoih0Lh5q1CVZDzgUTV37oXKvbjEiSOhIS5oZ5BaYuxM8aVGNIwNhmy2E0dRAiv881DgQ1ZUWa2NLoNIqgyWsQ1FHXjA8uImrDOxuhc+L9vrUJ0J7DKynlCfpcfm5oatmspdoMRcwDURXXNnqmzLzMNfqCIWYcv/3tb9dn82HwrPjUNl2QXf1uee5cMRXlH8RIY6pM7bSiHIpjSuqXv/xlNTugEo6r7mgSM2Ij2zVrjBwDYHRLmWazSURffNwFwfbco9K3eMY7mAlIjSt5Vp6nz5NpqxngMfS56IR/1113rc+049qy9AxFzG33boxN2/Usehq1T6aBd+et8mLG3ZffTlWm7GJG0b18bnjh3DSZuvLnYPqFMBJ8gsmDECakoLNY2D73lKLwLkZ1+z2j+ddRYOgkEGP3NkLnJPp4EjypmBdjVKGUvk6tgdfV9yzwdz4nSfnZz362OixGsded+N7CJuWxwoc+Q2JmxCYww0gQ+n1fzmKuYKQYVUlJ023jPJc8BsMWaxv9456jytWoLCjlH8ZKOo2Sgs/xMvpGj3FcfhAEVpqbmkvfIiIKwNuZRlWfJcWD9FUYwu+MRNZPWGuufNdhwwnuqS8+tSpS/N6XqGPUFEn5ItdhUsKPuYIcMYjC1mXLltVnR2fPPfesQtFYOwsl3/jGN9Y/zR0LWvkl5vqEqoFwpcSmKau3CIDrtaETuXCjZPkpXMzlNwKYg1ennooQqa+NuO7DU3wpRgPN+3quwcM5XpD3iQk2eGRCA/dsQyiU6/IzaE2uqOuwfkCb5sD4Kr3NMcBdCHN5e7Ekn7ZRom59xFyzYJVf8YnyyxT3vBkxuaAxCCA3LNYZFF9iZtttt62Upo1mSnG4Qi0GYZXpjylqTnINPIk+l78JhwZDCQrR9yyTQnuaH2d0255TH6fsVTeIthQaNrmirkNlnDbNMQAM4iRGfLz2ta9tXe7doG94ke95z3vqM9dmmqHQglR+02jPeMYzet2lBsJtE0pJwhhc/r4pMcJiVmLfffftLFjy90a/tvi1C4oaGyXdp22EjpFSqKRtJBCN1A2mYinltGNs9zZzI0cgf9NGU9iT0s8NOXkRMxxdRrwNhl3i2fT0OJgGFjLF2tg7G2gMWhLVbQfjOC0jnVXbb1qOK5Vjpdvw0kZqVs/tuWjcI4kfMaRzhDVVIJqFFrvttlt9ph2N7Pox11tSSpGFkt7YenvPaMSigMOr5Np4+tOfXrnoXcrqeu6VM5PQLGONCZipNTX/L3zhC+szofp/SahpxdlGWvflyjN6Kj+7UOxDwHPcfu3u+Qd3IupCmz/+8Y/PqspTLy/5ps9G4fTTT688uL59FSbBOLX9WcovDtKYk5iS0ShNwzAmBJiSOXJGJIJG+W0k0Ye69liHDCsgwbVcuKt2gJfAOhu9+lC4QQC77m00U+9uQUwK1r3bHqyvTpyxNkc9WDjiPhQ/1s7aNWfE1Hb+RpsYPZcuXdqbvW7eOdXDg3sYNOxVmIoNThj8VLnyDmRllKQuKD6PZxJ60secKb9sba5yThvumYxq38YK4nN70iuv7IIwmray5LPBz13um6YzbahcN7aDq+2xn/rUp0aFXCcKIyyPTsG2Zop7YqM3194hz9GgvkKB0nCF3SAUzLupMqQIKSJCLryfqVbrPFLgNdnPT1ycirwNryznizF9g64cUqqn4315uTySWH6oDZuTmh1JXQQ1LnOi/EbDrbfeOjp6zTUEmzAoU+2DkEk6SZB1oSHF+oNrw+0Bb2dVme02jI7Whrdt0Nlgmky+IXZvRoxAp8Sy9g1kJPpGfaGVSkHVZQ32PfA+sWIS7zQX3z83yjfwCstska6aMBWr+4SEOR4GWbCIp/limlRuf/vb91Y5JqrcNcSeeRzlTx7CjZy5iZlpogFlkX1bSgqSXLFY3/XEqcMLXyzGYGC6Osw1CZdtsLpQ0djnAjbFQ0KYGJ/85CerUum+ffLguYenrIy2fe3g73ISj6Pi+wVyXGPPxisZ3ny0D8VNQsuuPmyDQdLWOZgi7POMGznTzwxZ1+H3FNvnc547hyzln4sYJhUCuvnmmyfVwKfsZS8zzcUfHuGNFkbBvnn/WOZfZ/cpKuH0GV6ETLEMOW+LUaEkPBCzEAwE76sv9KIkrjm4NFSiTHK1L2FrKm3UtQupSO56xr73GMRzWe04ygDEU+jqwzYosRBJ2JOCvmIsYt4dJZYL4LnYKl2equvwe4lD7zzvyq++WYMsBHQIofn0pz9dn4nTFLTEhIZgdAm87ZWbmYk2XNt6Aco1DuJLii1Bp4rObINddbnHhx9+eHX/VNfVqDGcre6bbgRhS9mrb1w8S467D+FIzr4CgwiTDBipaCOH50zBjEpfGKZtJThzajkYyGmRpPySH1yRvhFj2hB+SiqWtXdAKn2LaVzXNdtKT+FbYLjZcgxt6HAew2BsPUjOJoyuRSnUETAEDgovRk9tf0piVkP+YpAUhfO3k6hu66Mps05FHzH6oyo/I4ocZZIgTBlgtKu8U2xw9PzC1Llaq59CkvKLl6c1J5yKTpMUowj2Ok/Npvobbn8sa+valCU2byxjbPTvQvsYndvcRKMO158ATBPX94yEUJ5hEKOOJdaxdmiMYOoXgo6KLLop1RyXn/E0Q2EKblQYjhzXX5irxLzPcEsm93lkTbsquFooJLU+N3S+4n2KqdKOsIiFbYOUE36krHojEH2umHnr2LSX6xOAtthfptl0Vo7g5SJnIeyQM2hbgqooxrP35T0YwNi680kwSlWfts/5DoM2GGFKmIrn423F9meUg9GmMa+MDHv+Ls9wvkhSftnsacT7hLE5NBALq5HEZmJWc+hGMsqj5NJXX+XSt4DFvbm6KYlD896xuLEZ/dtGCiMIgRc+UTL3HYemzTyPdtI/pvC6vgQzxeVnnObiq9O5/LEwrA19lLPUuQ2uvzbQbqno067CKwVUy5Yti06bgtdnA5NYMnA+6J3nt92xwg2x56RprKV/HQRCxZysu4IiUzR99fp98Fhsk9xFo/xd3yAziLYwshrhu+ClSNC97W1vq8/8L9bBi/vEfxTW4d1jI7JnbJSdYWE8/EswFdSoS9hss83qT7fDZfb52H14Vyo4u+rwJwHjp9qwz00exLubrRm33h7mwxX8pBof9zZD0ua1mW2yeCjmFesz/ZtTtt3gb+WLyEhXvxkkTXdbC5NLr/ITZgm/3EqnPrwYV9hLmSqbhmfBxYvteQ6v7/cWBqVgGsbfdAmu3zXThjFchzdgm2vPSPGM4sPXdT2KQljtF8+QyRib8mIoUxDvn3HGGb0Cz6Ck1MuPA0/Oiruc/tYGFGgS8TJ5TpnuHET7aevBEV4fS/L1jebkXP+NWvFnuo+OdMmbPpOvkiDOJau8t1AorDwkxfyFQmHloyh/oTCjFOUvFGaUovyFwoxSlL9QmFGi2X6/uuiSy8Kly7untgqFwvxBR9dYLYS111oja/oSUeWn+Ccee0RY89wTwopVF85y3kKh8P+sctWV4fy1Ng1b7bQ0rL9e/1fVDRJV/vMuuDSceuQeYZsly67+ZH2yUCgsKI6/eIew0S6HhQ03yCskisb8XP0Vq1w94lP8cpSjHAvyWLFk9ZHC8pLwKxRmlKL8hcKMUpS/UJhRivIXCjNKUf5CYUaJK79ZwBXLQ7DxSTnKUY6FeVyto5EZ+06i8/wXX3p5OOm4o8KKc0+52kxMfrONQqEwHkuuujJctvbGYcvtdg7rrZv+tWfoLe+9bPkVYfmVphPz5xELhcJ0WXH1f6uvGsIaq68W3aKtjajyFwqFlZeS8CsUZpSi/IXCjFKUv1CYUYryFwozSlH+QmFGKcpfKMwoRfkLhRmlKH+hMKMU5S8UZpIQ/g/2HY36j5E7MQAAAABJRU5ErkJggg=='>
				
				<p><b><a href='".URL.LANG."/activation/".$session."'>$c[activb]</a></b></p>
				</center>";

				mail($to, $subject, $txt, $headers);

				header('Location: '.ROOT.LANG.'/info/send-activ');
			}
		}
	}
}

?>