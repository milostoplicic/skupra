<?php

if (!defined('PROTECT')){die('Protected Content!');}

class Engine {
	
	public static function Signin($username, $password, $remember) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		$query = "SELECT * FROM users WHERE username = ? AND password = ?";
		$result = $link->GetRow($query, [$username, $password]);
		
		if ($result) {
			
			$_SESSION[SITE] = array(
			
				'username'		=> $result['username'],
				'session'		=> $result['session'],
				'usertype'		=> $result['usertype']
			);
			
			if ($remember == 1) {
				
				setcookie(SITE, $result['session'], time()+3600*24*30, '/');
			}
			
			header('Location: '.ROOT.LANG.'/blog');
		} else {
			
			return "<p class='red'>$c[nouser]</p>";
		}
	}
	
	public static function Contact($email, $message) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
			return "<p class='red'>$c[nevem]</p>";
		} else {
			
			mail(EMAIL, 'Message from site SkupRa', $message."\n\n$email", 'From:'.$email);
			
			header('Location: '.ROOT.LANG.'/info/email-sent');
		}
	}
	
	public static function SelectBox($catid) {

		$link = new DB();

		$query = "SELECT * FROM categories";
		$result = $link->GetRows($query);

		$output = '';

		foreach ($result as $cat) {

			if ($catid != '') {
				if ($cat['catid'] == $catid) {
					
					$selected = 'selected';
				} else {
					
					$selected = '';
				}
			} else {
				
				$selected = '';
			}
			
			$output .= "<option value='$cat[catid]' $selected>$cat[catname]</option>";
		}

		return $output;
	}
	
	public static function Write($engleski, $header, $header_en, $catid, $text, $text_en, $authorid, $minview, $comments) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$seo = self::SEO($header);
		
		$date = date("Y-m-d");
		
		$dateseo = date("d-m-Y");
		$seo = $seo.'-'.$dateseo;
		
		$link = new DB();
		$query = "SELECT * FROM articles WHERE seo = ?";
		$result = $link->GetRow($query, [$seo]);
		
		if ($result) {
			
			return "<p class='red'>$c[promese]</p>";
		} else {
			
			$query = "INSERT INTO articles(engleski, header, header_en, seo, date, catid, tekst, tekst_en, pregledi, authorid, minview, comments) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$result = $link->InsertRow($query, [$engleski, $header, $header_en, $seo, $date, $catid, $text, $text_en, 0, $authorid, $minview, $comments]);
			
			header('Location: '.ROOT.LANG.'/info/write-success');
		}
	}
	
	private static function SEO($input) {

		$cir = array (
			
			"А" => "a", "Б" => "b", "В" => "v", "Г" => "g", "Д" => "d", "Ђ" => "dj", "Е" => "e", "Ж" => "z", "З" => "z", "И" => "i", 
			"Ј" => "j", "К" => "k", "Л" => "l", "Љ" => "lj", "М" => "m", "Н" => "n", "Њ" => "nj", "О" => "o", "П" => "p", "Р" => "r", 
			"С" => "s", "Т" => "t", "Ћ" => "c", "У" => "u", "Ф" => "f", "Х" => "h", "Ц" => "c", "Ч" => "c", "Џ" => "dz", "Ш" => "s", 

			"а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "ђ" => "dj", "е" => "e", "ж" => "z", "з" => "z", "и" => "i", 
			"ј" => "j", "к" => "k", "л" => "l", "љ" => "lj", "м" => "m", "н" => "n", "њ" => "nj", "о" => "o", "п" => "p", "р" => "r", 
			"с" => "s", "т" => "t", "ћ" => "c", "у" => "u", "ф" => "f", "х" => "h", "ц" => "c", "ч" => "c", "џ" => "dz", "ш" => "s",
			
			"Š" => "s", "Đ" => "dj", "Č" => "c", "Ć" => "c", "Ž" => "z",
			"š" => "s", "đ" => "dj", "č" => "c", "ć" => "c", "ž" => "z"
		);

		$output = strtr($input, $cir);
		$output = strtolower($output);
		$output = preg_replace("/[\s]/", "-", $output);
		$output = preg_replace("/[^a-z0-9-_]/",'',$output);

		return $output;
	}
	
	public static function Pagination($page, $num_page, $folder) {

		$pag1 = "<div id='pagi'>";
		$pag2 = '';

		for($i = 1; $i <= $num_page; $i++) {
			
			if($i==$page) {
				
				$pag2 .= "&nbsp;".$i."&nbsp;";
			} else {
				
				$pag2 .= "&nbsp;<a href='".ROOT.LANG.'/'.$folder.'/'.$i."'>".$i."</a>&nbsp;";
			}
		}
		
		$pag3 = '</div>';

		return $pag1.$pag2.$pag3;
	}
	
	public static function Edit($engleski, $header_en, $tekst_en, $artid, $header, $seo, $oldseo, $catid, $tekst, $minview, $comments) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$seo = self::SEO($seo);
		
		if ($seo == $oldseo) {

			$query = "UPDATE articles SET engleski = ?, header_en = ?, tekst_en = ?, header = ?, catid = ?, tekst = ?, minview = ?, comments = ? WHERE artid = ?";
			$result = $link->UpdateRow($query, [$engleski, $header_en, $tekst_en, $header, $catid, $tekst, $minview, $comments, $artid]);
		} else {

			$query = "SELECT * FROM articles WHERE seo = ?";
			$result = $link->GetRow($query, [$seo]);

			if ($result) {

				return "<p class='red'>".$c['prose']."</p>";
			} else {

				$query = "UPDATE articles SET engleski = ?, header_en = ?, tekst_en = ?, header = ?, seo = ?, catid = ?, tekst = ?, minview = ?, comments = ? WHERE artid = ?";
				$result = $link->UpdateRow($query, [$engleski, $header_en, $tekst_en, $header, $seo, $catid, $tekst, $minview, $comments, $artid]);
			}
		}

		if ($result) {
			
			header('Location: '.ROOT.LANG.'/info/edit-success');
		}
	}
	
	public static function AddCategory($catname, $opis, $catname_en, $opis_en, $image) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$catseo = self::SEO($catname);
		
		$link = new DB();
		$query = "SELECT * FROM categories WHERE catseo = ?";
		$result = $link->GetRow($query, [$catseo]);
		
		if ($result) {
			
			return "<p class='red'>$c[catex]</p>";
		} else {
			
			$query = "INSERT INTO categories (catname, catname_en, catdesc_en, catseo, catdesc, image) VALUES (?, ?, ?, ?, ?, ?)";
			$result = $link->InsertRow($query, [$catname, $catname_en, $opis_en, $catseo, $opis, $image]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/add-category-success');
			}
		}
	}
	
	public static function EditCategory($catid, $catname, $oldcatname, $opis, $image, $catname_en, $opis_en) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$catseo = self::SEO($catname);
		$oldcatseo = self::SEO($oldcatname);
		
		$link = new DB();
		
		if ($catseo == $oldcatseo) {
			
			$query = "UPDATE categories SET catname = ?, catdesc = ?, image = ?, catname_en = ?, catdesc_en = ? WHERE catid = ?";
			$result = $link->UpdateRow($query, [$catname, $opis, $image, $catname_en, $opis_en, $catid]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/edit-category-success');
			}
		} else {
			
			$query = "SELECT * FROM categories WHERE catseo = ?";
			$result = $link->GetRow($query, [$catseo]);
			
			if ($result) {
				
				return "<p class='red'>$c[catexe]</p>";
			} else {
				
				$query = "UPDATE categories SET catname = ?, catseo = ?, catdesc = ?, image = ?, catname_en = ?, catdesc_en = ? WHERE catid = ?";
				$result = $link->UpdateRow($query, [$catname, $catseo, $opis, $image, $catname_en, $opis_en, $catid]);
				
				if ($result) {
				
					header('Location: '.ROOT.LANG.'/info/edit-category-success');
				}
			}
		}
	}
	
	public static function CatName($catid, $engleski) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		if ($engleski == 0) {

			$query = "SELECT catname FROM categories WHERE catid = ?";

			$result = $link->GetRow($query, [$catid]);
		
			if ($result) {
				
				return $result['catname'];
			} else {
				
				return $c['nocat'];
			}
		} else {

			$query = "SELECT catname_en FROM categories WHERE catid = ?";

			$result = $link->GetRow($query, [$catid]);
		
			if ($result) {
				
				return $result['catname_en'];
			} else {
				
				return $c['nocat'];
			}
		}
	}
	
	public static function CatId($catseo) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT catid FROM categories WHERE catseo = ?";
		$result = $link->GetRow($query, [$catseo]);
		
		if ($result) {
			
			return $result['catid'];
		} else {
			
			return $c['nocat'];
		}
	}
	
	public static function AuthorId($username) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT userid FROM users WHERE username = ?";
		$result = $link->GetRow($query, [$username]);
		
		if ($result) {
			
			return $result['userid'];
		} else {
			
			return $c['noauthor'];
		}
	}
	
	public static function Author($userid) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT username FROM users WHERE userid = ?";
		$result = $link->GetRow($query, [$userid]);
		
		if ($result) {
			
			return $result['username'];
		} else {
			
			return $c['noauthor'];
		}
	}

	public static function CatSeo($catid) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT catseo FROM categories WHERE catid = ?";
		$result = $link->GetRow($query, [$catid]);
		
		if ($result) {
			
			return $result['catseo'];
		} else {
			
			return $c['nocat'];
		}
	}

	public static function Email($email) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
			return "<p class='red'>$c[nevem]</p>";
		} else {

			$link = new DB();
			$query = "SELECT * FROM users WHERE email = ?";
			$result = $link->GetRow($query, [$email]);

			if ($result) {

				if ($result['activ'] == 0) {

					header('Location: '.ROOT.LANG.'/info/activation');
				} else {
					
					$_SESSION[SITE] = array(
			
						'username'		=> $result['username'],
						'session'		=> $result['session'],
						'usertype'		=> 1
					);
				
					setcookie(SITE, $result['session'], time()+3600*24*30, '/');
			
					header('Location: '.ROOT.LANG.'/blog');
				}
			} else {

				$username = explode('@', $email);
				$username = $username[0];

				$session = md5($email);
				$usertype = 1;

				$query = "INSERT INTO users (username, email, session, usertype) VALUES (?, ?, ?, ?)";
				$result = $link->InsertRow($query, [$username, $email, $session, $usertype]);

				$to = $email;

				$subject = ':: SkupRa';

				$headers = "From: office@skupra.com\r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
				
				$txt = 
				"
				<h2>:: SkupRa</h2>
				<p><b><a href='".URL.LANG."/activation/".$session."'>$c[activb]</a></b></p>
				";

				mail($to, $subject, $txt, $headers);

				header('Location: '.ROOT.LANG.'/info/send-activ');
			}
		}
	}
}

?>