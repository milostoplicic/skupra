<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s = '';
$e = '';

if (C3 != '') {
	
	$link = new DB();
	
	$query = "SELECT * FROM categories WHERE catseo = ?";
	$result = $link->GetRow($query, [C3]);
	
	if ($result) {
		
		if (isset($_POST['submit'])) {
			
			if (empty($_POST['catname']) OR empty($_POST['opis']) OR empty($_POST['opis_en']) OR empty($_POST['catname_en'])) {
		
				$e = "<p class='red'>$c[fill]</p>";
			} else {
				
				$e = Engine::EditCategory($result['catid'], $_POST['catname'], $result['catname'], $_POST['opis'], $_POST['image'], $_POST['catname_en'], $_POST['opis_en']);
			}
		}
		
		$s =
		"
		<form action='' method='post'>
		$c[imcat1]<br>
		<input type='text' name='catname' maxlength='64' placeholder='$c[imec2]' value='$result[catname]' class='fil3'><br><br>
		$c[opis]<br>
		<textarea class='fil2' name='opis' maxlength='200' placeholder='$c[opis2]'>$result[catdesc]</textarea><br><br>
		$c[imec_en]<br>
		<input type='text' name='catname_en' maxlength='64' placeholder='$c[imec2_en]' value='$result[catname_en]' class='fil3'><br><br>
		$c[opis_en]<br>
		<textarea class='fil2' name='opis_en' maxlength='200' placeholder='$c[opis2_en]'>$result[catdesc_en]</textarea><br><br>
		$c[putsli]<br>
		<input type='text' name='image' maxlength='128' placeholder='$c[puts2]' value='$result[image]' class='fil3'><br><br>
		<input type='submit' name='submit' class='but1' value='$c[pot]'>
		</form>
		";
	} else {
		
		$e = "<p class='red'>$c[nocat]</p>";
	}
} else {
	
	$link = new DB();
		
	$query1 = "SELECT COUNT(*) FROM categories";
	$count = $link->GetRow($query1);

	$total = ($count['COUNT(*)']);

	if ($total > 0) {
		
		$limit = 30;
		$page = (C2 != '') ? C2 : 1;
		$start = $limit * ($page-1);
		$num_page = ceil($total/$limit);
		
		$query = "SELECT * FROM categories ORDER BY catid DESC LIMIT $start, $limit";
		$result = $link->GetRows($query);

		foreach ($result as $r) {
			
			$s .= "<p><a href='".ROOT.LANG."/edituj-kategoriju/".$page.'/'.$r['catseo']."'><b>$r[catid]</b> | $r[catname] | $r[catseo]</a></p>";
		}
		
		$s .= Engine::Pagination($page, $num_page, 'edituj-kategoriju');
	} else {
		
		$s = "<p class='red'>$c[nocat]</p>";
	}
}

$cont =
"
<div id='cont'>
<h1>$c[edcat]</h1>
$e
$s
</div>
";

?>