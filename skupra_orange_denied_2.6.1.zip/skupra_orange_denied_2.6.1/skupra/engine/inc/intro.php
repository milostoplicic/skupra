<?php

if (!defined('PROTECT')){die('Protected Content!');}

if ($_SESSION[SITE]['usertype'] > 0) {

	header('Location: '.ROOT.LANG.'/blog');
}

$e = "<p>&nbsp</p>";

if (isset($_POST['submit'])) {

	if ($_POST['email'] == '') {

		$e = "<p class='red'>$c[une]</p>";
	} else {

		$e = Engine::Email($_POST['email']);
	}
}

$cont =
"<center>
<div class='intro'>
<a href='".ROOT."'><img src='".ROOT."look/img/skupra.png'></a><br>
<div id='linkse'><a href='".ROOT."eng'>Eng</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='".ROOT."cyr'>Cyr</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='".ROOT."lat'>Lat</a></div>
$e
<form action='' method='post'>
<input type='text' name='email' class='fil1' placeholder='$c[email]'><br>
<input type='submit' name='submit' class='but1' value='$c[pot]'>
</form>
</div>
</center>
";
?>