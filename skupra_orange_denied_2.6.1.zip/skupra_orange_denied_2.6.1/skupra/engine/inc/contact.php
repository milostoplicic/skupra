<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (isset($_POST['submit'])) {
	
	$email = $_POST['email'];
	$message = $_POST['message'];
	
	if (empty($email) OR empty($message)) {
		
		$e = "<p class='red'>$c[popobpo]</p>";
	} else {
		
		$e = Engine::Contact($email, $message);
	}
}

$cont =
"
<div id='cont'>
<h1>$c[contact]</h1>
<p>
<b>$c[developer]</b><br>
$c[mobilni] +381 62 186 86 94<br>
$c[eposta] milostoplicic@gmail.com
</p>
$e
<form action='' method='post'>
$c[vasae]<br>
<input type='text' name='email' maxlength='64' placeholder='$c[email]' class='fil3'><br><br>
$c[por1]<br>
<textarea class='fil2' name='message' maxlength='200' placeholder='$c[por2]'></textarea><br><br>
<input type='submit' name='submit' class='but1' value='$c[posalji]'>
</form>
</div>
";

?>