<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s = '';

$link = new DB();

$catid = Engine::CatId(C2);

if (LANG == 'eng') {
	
	$catname = Engine::CatName($catid, 1);
} else {
	
	$catname = Engine::CatName($catid, 0);
}

$query1 = "SELECT COUNT(*) FROM articles WHERE catid = ?";
$count = $link->GetRow($query1, [$catid]);

$total = ($count['COUNT(*)']);

if ($total > 0) {
	
	$limit = 30;
	$page = (C3 != '') ? C3 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);
	
	$query = "SELECT * FROM articles WHERE catid = ? ORDER BY artid DESC LIMIT $start, $limit";
	$result = $link->GetRows($query, [$catid]);

	foreach ($result as $r) {
		
		if ($r['comments'] == 0) {
			
			$co = ' | '.$c['comof'];
		} else {

			$queryc = "SELECT COUNT(*) FROM comments WHERE artid = ? AND pub = 1";
			$resultc = $link->GetRow($queryc, [$r['artid']]);

			$tot = $resultc['COUNT(*)'];

			$co = ' | '.$c['come']." <b>".$tot."</b>";
		}

		$date = explode('-', $r['date']);
		$date = $date[2].'.'.$date[1].'.'.$date[0];
		
		$string = mb_substr(strip_tags($r['tekst'], '<img>'), 0, $r['minview'], 'utf-8');
		
		$cat = Engine::CatName($r['catid'], $r['engleski']);

		$author = Engine::Author($r['authorid']);
		
		$s .= 
		"
		<h2><a href='".ROOT.LANG."/clanak/".$r['seo']."'>$r[header]</a></h2>
		<p class='date'>$c[date] <b>$date</b> | $c[cate] <b>$cat</b> | $c[author] <a href='".ROOT.LANG."/clanci-od-korisnika/".$author."'><b>$author</b></a> | $c[pregledi] <b>$r[pregledi]</b>$co</p>
		<p>".$string." ... <a href='".ROOT.LANG."/clanak/".$r['seo']."'>$c[readmore]</a></p>
		<div class='clear'></div>
		<div class='line'></div>
		";
	}
	
	$s .= Engine::Pagination($page, $num_page, 'kategorija/'.C2);
} else {
	
	$s = "<p class='red'>$c[noart]</p>";
}

$cont =
"
<div id='cont'>
<h1>$c[cate] $catname</h1>
$s
</div>
";

?>