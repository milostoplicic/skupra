<?php

if (!defined('PROTECT')){die('Protected Content!');}

$cont = '';

$link = new DB();
$query = "SELECT * FROM users WHERE session = ?";
$result = $link->GetRow($query, [C2]);

if ($result) {

	$query = "UPDATE users SET activ = 1 WHERE session = ?";
	$result = $link->UpdateRow($query, [C2]);

	$_SESSION[SITE]['usertype'] = 1;

	setcookie(SITE, C2, time()+3600*24*30, '/');

	header('Location: '.ROOT.LANG.'/blog');
}

?>