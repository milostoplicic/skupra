<?php

if (!defined('PROTECT')){die('Protected Content!');}

$link = new DB();

if (!isset($_SESSION[SITE][C1])) {
	
	$query1 = "UPDATE articles SET pregledi = pregledi + 1 WHERE seo = ?";
	$result1 = $link->UpdateRow($query1, [C1]);

	$_SESSION[SITE][C1] = 1;
}
	
$query = "SELECT * FROM articles WHERE seo = ?";
$result = $link->GetRow($query, ['manifest']);

if ($result) {
	
	$s = $result['tekst'];
} else {
	
	$s = '';
}

$cont =
"
<div id='cont'>
<h1>$c[manifest]</h1>
$s
</div>
";

?>