<?php

if (!defined('PROTECT')){die('Protected Content!');}

$authorid = Engine::AuthorId($_SESSION[SITE]['username']);

$s = '';

if (C3 != '') {
	
	$error = '';
	
	$link = new DB();
	
	if ($_SESSION[SITE]['usertype'] == 3) {
		
		$query = "SELECT * FROM articles WHERE seo = ?";
		$result = $link->GetRow($query, [C3]);
	} else if ($_SESSION[SITE]['usertype'] == 2) {
		
		$query = "SELECT * FROM articles WHERE seo = ? AND authorid = ?";
		$result = $link->GetRow($query, [C3, $authorid]);
	}

	
	if ($result) {
		
		if ($result['comments'] == 0) {

			$checked = '';
		} else {

			$checked = 'checked';
		}

		if (isset($_POST['submit'])) {
	
			if (empty($_POST['header']) OR empty($_POST['seo']) OR empty($_POST['tekst'])) {
				
				$error = "<p class='red'>$c[popobpo]</p>";
			} else {
				
				$comments = isset($_POST['comments']) ? 1 : 0;
				$engleski = isset($_POST['engleski']) ? 1 : 0;
				
				$error = Engine::Edit($engleski, $_POST['header_en'], $_POST['tekst_en'], $result['artid'], $_POST['header'], $_POST['seo'], $result['seo'], $_POST['catid'], $_POST['tekst'], $_POST['minview'], $comments);
			}
		}
		
		$selectbox = Engine::SelectBox($result['catid']);
		
		$s =
		"
		$error
		<form action='' method='post'>
		$c[naslov]&nbsp;&nbsp;<input type='text' name='header' class='fil3' maxlength='128' value='$result[header]'><br><br>
		$c[seo]&nbsp;&nbsp;<input type='text' name='seo' class='fil3' maxlength='128' value='$result[seo]'><br><br>
		$c[kategori]&nbsp;&nbsp;<select class='selbox1' name='catid'>$selectbox</select><br><br>
		$c[predpregled] <input type='text' name='minview' class='fil4' value='$result[minview]'><br><br>
		$c[comen2] <input type='checkbox' name='comments' $checked><br><br>
		$c[tekst]<br>
		<textarea id='edit' name='tekst'>$result[tekst]</textarea><br><br>
		$c[eng] <input type='checkbox' id='check' name='engleski' onclick='Engleski()'><br><br>
		<div id='engleski' style='display:none'>
		$c[naslov_en]&nbsp;&nbsp;<input type='text' name='header_en' class='fil3' maxlength='128' value='$result[header_en]'><br><br>
		<textarea id='edit_en' name='tekst_en'>$result[tekst_en]</textarea>
		</div><br><br>
		<input type='submit' name='submit' class='but1' value='$c[pot]'>
		</form>
		<script src='".ROOT."engine/tinymce/tinymce.min.js'></script>
		<script>tinymce.init({
				relative_urls : false,
				remove_script_host : true,
				document_base_url : '".ROOT."',
				content_css : '".ROOT.'look/css/style.css'."',
				  selector: 'textarea',
				  height: 400,
				  theme: 'modern',
				  plugins: [
					'advlist autolink lists link image charmap print preview hr anchor pagebreak',
					'searchreplace wordcount visualblocks visualchars code fullscreen',
					'insertdatetime media nonbreaking save table contextmenu directionality',
					'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
				  ],
				  toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
				  toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
				  image_advtab: true
				 });

			function Engleski() {
			var checkBox = document.getElementById('check');
			var text = document.getElementById('engleski');
			if (checkBox.checked == true){
			text.style.display = 'block';
			} else {
			text.style.display = 'none';
			}
			}
		</script>
		";
	} else {
		
		$s = "<p class='red'>$c[noart2]</p>";
	}
} else {
	
	$link = new DB();
	
	if ($_SESSION[SITE]['usertype'] == 3) {
		
		$query1 = "SELECT COUNT(*) FROM articles";
		$count = $link->GetRow($query1);
	} else if ($_SESSION[SITE]['usertype'] == 2) {
		
		$query1 = "SELECT COUNT(*) FROM articles WHERE authorid = ?";
		$count = $link->GetRow($query1, [$authorid]);
	}
	
	$total = ($count['COUNT(*)']);
	
	if ($total > 0) {
		
		$limit = 30;
		$page = (C2 != '') ? C2 : 1;
		$start = $limit * ($page-1);
		$num_page = ceil($total/$limit);
		
		if ($_SESSION[SITE]['usertype'] == 3) {
			
			$query = "SELECT * FROM articles ORDER BY artid DESC LIMIT $start, $limit";
			$result = $link->GetRows($query);
		} else if ($_SESSION[SITE]['usertype'] == 2) {
			
			$query = "SELECT * FROM articles WHERE authorid = ? ORDER BY artid DESC LIMIT $start, $limit";
			$result = $link->GetRows($query, [$authorid]);
		}
		
		foreach ($result as $r) {
			
			$s .= "<p><a href='".ROOT.LANG."/edituj/".$page.'/'.$r['seo']."'><b>$r[artid]</b> | $r[header] | $r[seo]</a></p>";
		}
		
		$s .= Engine::Pagination($page, $num_page, 'edituj');
	} else {
		
		$s = "<p class='red'>$c[noart]</p>";
	}
}

if ($_SESSION[SITE]['usertype'] == 3) {
	
	$ddd = '';
} else if ($_SESSION[SITE]['usertype'] == 2) {
	
	$ddd = $c['svoje'];
}

$cont =
"
<div id='cont'>
<h1>$c[edituj] $ddd $c[clanke]</h1>
$s
</div>
";

?>