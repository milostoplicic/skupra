<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

$authorid = Engine::AuthorId($_SESSION[SITE]['username']);
	
if (isset($_POST['submit'])) {
	
	$id = $_POST['id'];
	
	$link = new DB();
	
	if ($_SESSION[SITE]['usertype'] == 3) {
	
		$query = "DELETE FROM articles WHERE artid = ?";
		$result = $link->DeleteRow($query, [$id]);
	} else if ($_SESSION[SITE]['usertype'] == 2) {
		
		$query = "DELETE FROM articles WHERE artid = ? AND authorid = ?";
		$result = $link->DeleteRow($query, [$id, $authorid]);
	}
	
	if ($result) {
		
		header('Location: '.ROOT.LANG.'/info/delete-success');
	} else {
		
		$e = "<p class='red'>$c[noart2]</p>";
	}
}

$s = '';

$link = new DB();

if ($_SESSION[SITE]['usertype'] == 3) {	
	
	$query1 = "SELECT COUNT(*) FROM articles";
	$count = $link->GetRow($query1);
} else if ($_SESSION[SITE]['usertype'] == 2) {
	
	$query1 = "SELECT COUNT(*) FROM articles WHERE authorid = ?";
	$count = $link->GetRow($query1, [$authorid]);
}

$total = ($count['COUNT(*)']);

if ($total > 0) {	
	
	$limit = 30;
	$page = (C2 != '') ? C2 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);
	
	if ($_SESSION[SITE]['usertype'] == 3) {
		
		$query = "SELECT * FROM articles ORDER BY artid DESC LIMIT $start, $limit";
		$result = $link->GetRows($query);
	} else if ($_SESSION[SITE]['usertype'] == 2) {
		
		$query = "SELECT * FROM articles WHERE authorid = ? ORDER BY artid DESC LIMIT $start, $limit";
		$result = $link->GetRows($query, [$authorid]);
	}
	
	foreach ($result as $r) {
		
		$s .= "<p><b>$r[artid]</b> | $r[header] | $r[seo]</p>";
	}

	$s .=
	"
	<form action='' method='post'>
	$c[delart]<br><br>
	$c[id] <input type='text' name='id' class='fil4'>
	<input type='submit' name='submit' class='but1' value='$c[izb]'>
	</form>
	";

	$s .= Engine::Pagination($page, $num_page, 'izbrisi');
} else {
	
	$s = "<p class='red'>$c[noart]</p>";
}

if ($_SESSION[SITE]['usertype'] == 3) {
	
	$ddd = '';
} else if ($_SESSION[SITE]['usertype'] == 2) {
	
	$ddd = $c['svoj'];
}

$cont =
"
<div id='cont'>
<h1>$c[izb] $ddd $c[clanak]</h1>
$e
$s
</div>
";

?>