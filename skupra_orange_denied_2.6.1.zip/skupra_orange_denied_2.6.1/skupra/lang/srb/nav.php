<?php

if (!defined('PROTECT')){die('Protected Content!');}

$c = array(

	'intro'			=> 'Интро',
	'blog'			=> 'Блог',
	'categories'	=> 'Категорије',
	'archive'		=> 'Архива',
	'manifest'		=> 'Манифест',
	'contact'		=> 'Контакт',
	'lang'			=> 'Писмо/Језик',
	'cyr'			=> 'СР Ћирилица',
	'lat'			=> 'SR Latinica',
	'eng'			=> 'English'
);

?>