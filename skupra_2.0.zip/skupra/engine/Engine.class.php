<?php

if (!defined('PROTECT')){die('Protected Content!');}

class Engine {
	
	public static function Signin($username, $password, $remember) {
		
		$link = new DB();
		$query = "SELECT * FROM users WHERE username = ? AND password = ?";
		$result = $link->GetRow($query, [$username, $password]);
		
		if ($result) {
			
			$_SESSION[SITE] = array(
			
				'username'		=> $result['username'],
				'session'		=> $result['session'],
				'usertype'		=> $result['usertype']
			);
			
			if ($remember == 1) {
				
				setcookie(SITE, $result['session'], time()+3600*24*30, '/');
			}
			
			header('Location: '.ROOT.LANG.'/'.HOME);
		} else {
			
			return "<p class='red'>Нема таквог корисника!</p>";
		}
	}
	
	public static function Contact($email, $message) {
		
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
			return "<p class='red'>Неважећи формат е-поште!</p>";
		} else {
			
			mail(EMAIL, 'Message from site Skupra', $message."\n\n$email", 'From:'.$email);
			
			header('Location: '.ROOT.LANG.'/info/email-sent');
		}
	}
	
	public static function SelectBox($catid) {

		$link = new DB();

		$query = "SELECT * FROM categories";
		$result = $link->GetRows($query);

		$output = '';

		foreach ($result as $cat) {

			if ($catid != '') {
				if ($cat['catid'] == $catid) {
					
					$selected = 'selected';
				} else {
					
					$selected = '';
				}
			} else {
				
				$selected = '';
			}
			
			$output .= "<option value='$cat[catid]' $selected>$cat[catname]</option>";
		}

		return $output;
	}
	
	public static function Write($header, $catid, $text, $authorid, $minview, $comments) {
		
		$seo = self::SEO($header);
		
		$date = date("Y-m-d");
		
		$dateseo = date("d-m-Y");
		$seo = $seo.'-'.$dateseo;
		
		$link = new DB();
		$query = "SELECT * FROM articles WHERE seo = ?";
		$result = $link->GetRow($query, [$seo]);
		
		if ($result) {
			
			return "<p class='red'>Промените наслов. Тај (SEO) већ постоји!</p>";
		} else {
			
			$query = "INSERT INTO articles(header, seo, date, catid, tekst, pregledi, authorid, minview, comments) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$result = $link->InsertRow($query, [$header, $seo, $date, $catid, $text, 0, $authorid, $minview, $comments]);
			
			header('Location: '.ROOT.LANG.'/info/write-success');
		}
	}
	
	private static function SEO($input) {

		$cyr = array (
			
			"А" => "a", "Б" => "b", "В" => "v", "Г" => "g", "Д" => "d", "Ђ" => "dj", "Е" => "e", "Ж" => "z", "З" => "z", "И" => "i", 
			"Ј" => "j", "К" => "k", "Л" => "l", "Љ" => "lj", "М" => "m", "Н" => "n", "Њ" => "nj", "О" => "o", "П" => "p", "Р" => "r", 
			"С" => "s", "Т" => "t", "Ћ" => "c", "У" => "u", "Ф" => "f", "Х" => "h", "Ц" => "c", "Ч" => "c", "Џ" => "dz", "Ш" => "s", 

			"а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "ђ" => "dj", "е" => "e", "ж" => "z", "з" => "z", "и" => "i", 
			"ј" => "j", "к" => "k", "л" => "l", "љ" => "lj", "м" => "m", "н" => "n", "њ" => "nj", "о" => "o", "п" => "p", "р" => "r", 
			"с" => "s", "т" => "t", "ћ" => "c", "у" => "u", "ф" => "f", "х" => "h", "ц" => "c", "ч" => "c", "џ" => "dz", "ш" => "s",
			
			"Š" => "s", "Đ" => "dj", "Č" => "c", "Ć" => "c", "Ž" => "z",
			"š" => "s", "đ" => "dj", "č" => "c", "ć" => "c", "ž" => "z"
		);

		$output = strtr($input, $cyr);
		$output = strtolower($output);
		$output = preg_replace("/[\s]/", "-", $output);
		$output = preg_replace("/[^a-z0-9-_]/",'',$output);

		return $output;
	}
	
	public static function Pagination($page, $num_page, $folder) {

		$pag1 = "<div id='pagi'>";
		$pag2 = '';

		for($i = 1; $i <= $num_page; $i++) {
			
			if($i==$page) {
				
				$pag2 .= "&nbsp;".$i."&nbsp;";
			} else {
				
				$pag2 .= "&nbsp;<a href='".ROOT.LANG.'/'.$folder.'/'.$i."'>".$i."</a>&nbsp;";
			}
		}
		
		$pag3 = '</div>';

		return $pag1.$pag2.$pag3;
	}
	
	public static function Edit($artid, $header, $seo, $oldseo, $catid, $tekst, $minview, $comments) {
		
		$link = new DB();
		
		$seo = self::SEO($seo);
		
		if ($seo == $oldseo) {
			
			$query = "UPDATE articles SET header = ?, seo = ?, catid = ?, tekst = ?, minview = ?, comments = ? WHERE artid = ?";
			$result = $link->UpdateRow($query, [$header, $seo, $catid, $tekst, $minview, $comments, $artid]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/edit-success');
			}
		} else {
			
			$query = "SELECT * FROM articles WHERE seo = ?";
			$result = $link->GetRow($query, [$seo]);
			
			if ($result) {
				
				return "<p class='red'>Промените СЕО (SEO). Тај већ постоји!</p>";
			} else {
				
				$query = "UPDATE articles SET header = ?, seo = ?, catid = ?, tekst = ? minview = ?, comments = ? WHERE artid = ?";
				$result = $link->UpdateRow($query, [$header, $seo, $catid, $tekst, $minview, $comments, $artid]);
			
				if ($result) {
				
					header('Location: '.ROOT.LANG.'/info/edit-success');
				}
			}
		}
	}
	
	public static function AddCategory($catname, $opis, $image) {
		
		$catseo = self::SEO($catname);
		
		$link = new DB();
		$query = "SELECT * FROM categories WHERE catseo = ?";
		$result = $link->GetRow($query, [$catseo]);
		
		if ($result) {
			
			return "<p class='red'>Та категорија већ постоји!</p>";
		} else {
			
			$query = "INSERT INTO categories (catname, catseo, catdesc, image) VALUES (?, ?, ?, ?)";
			$result = $link->InsertRow($query, [$catname, $catseo, $opis, $image]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/add-category-success');
			}
		}
	}
	
	public static function EditCategory($catid, $catname, $oldcatname, $opis, $image) {
		
		$catseo = self::SEO($catname);
		$oldcatseo = self::SEO($oldcatname);
		
		$link = new DB();
		
		if ($catseo == $oldcatseo) {
			
			$query = "UPDATE categories SET catname = ?, catdesc = ?, image = ? WHERE catid = ?";
			$result = $link->UpdateRow($query, [$catname, $opis, $image, $catid]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/edit-category-success');
			}
		} else {
			
			$query = "SELECT * FROM categories WHERE catseo = ?";
			$result = $link->GetRow($query, [$catseo]);
			
			if ($result) {
				
				return "<p class='red'>То име категорије већ постоји! Изаберите друго.</p>";
			} else {
				
				$query = "UPDATE categories SET catname = ?, catseo = ?, catdesc = ?, image = ? WHERE catid = ?";
				$result = $link->UpdateRow($query, [$catname, $catseo, $opis, $image, $catid]);
				
				if ($result) {
				
					header('Location: '.ROOT.LANG.'/info/edit-category-success');
				}
			}
		}
	}
	
	public static function CatName($catid) {
		
		$link = new DB();
		
		$query = "SELECT catname FROM categories WHERE catid = ?";
		$result = $link->GetRow($query, [$catid]);
		
		if ($result) {
			
			return $result['catname'];
		} else {
			
			return "Нема те категорије!";
		}
	}
	
	public static function CatId($catseo) {
		
		$link = new DB();
		
		$query = "SELECT catid FROM categories WHERE catseo = ?";
		$result = $link->GetRow($query, [$catseo]);
		
		if ($result) {
			
			return $result['catid'];
		} else {
			
			return "Нема те категорије!";
		}
	}
	
	public static function AuthorId($username) {
		
		$link = new DB();
		
		$query = "SELECT userid FROM users WHERE username = ?";
		$result = $link->GetRow($query, [$username]);
		
		if ($result) {
			
			return $result['userid'];
		} else {
			
			return "Нема тог аутора!";
		}
	}
	
	public static function Author($userid) {
		
		$link = new DB();
		
		$query = "SELECT username FROM users WHERE userid = ?";
		$result = $link->GetRow($query, [$userid]);
		
		if ($result) {
			
			return $result['username'];
		} else {
			
			return "Нема тог аутора!";
		}
	}

	public static function CatSeo($catid) {
		
		$link = new DB();
		
		$query = "SELECT catseo FROM categories WHERE catid = ?";
		$result = $link->GetRow($query, [$catid]);
		
		if ($result) {
			
			return $result['catseo'];
		} else {
			
			return "Нема те категорије!";
		}
	}
}

?>