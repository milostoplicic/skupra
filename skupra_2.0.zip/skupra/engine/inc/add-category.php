<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (isset($_POST['submit'])) {
	
	$catname = $_POST['catname'];
	$opis = $_POST['opis'];
	$image = $_POST['image'];
	
	if (empty($catname) OR empty($opis)) {
		
		$e = "<p class='red'>Попуните поља!</p>";
	} else {
		
		$e = Engine::AddCategory($catname, $opis, $image);
	}
}

$cont =
"
<div id='cont'>
<h1>Додај категорију</h1>
$e
<form action='' method='post'>
Име категорије(*):<br>
<input type='text' name='catname' maxlength='64' placeholder='Име категорије' class='fil3'><br><br>
Опис(*):<br>
<textarea class='fil2' name='opis' maxlength='200' placeholder='Опис (200 карактера)'></textarea><br><br>
Путања до слике:<br>
<input type='text' name='image' maxlength='128' placeholder='Путања до слике' class='fil3'><br><br>
<input type='submit' name='submit' class='but1' value='Потврди'>
</form>
</div>
";

?>