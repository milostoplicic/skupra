<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';
$s = '';

if (isset($_POST['submit'])) {

	if ($_FILES['photo']['name']) {

		if ($_FILES['photo']['size'] > (1024000)) {

			$e .= "<p class='red'>Слика је превелика. Треба бити мања од 1mb!</p>";
		} else {
		
			$imageFileType = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);

			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {

				$e .= "<p class='red'>Изгледа да фајл није слика!</p>";
			} else {
				
				$rand = rand(0, 100);
				
				$date = date("m-Y");
				
				if (!file_exists('content/img/'.$date)) {
					
					mkdir('content/img/'.$date, 0777, true);
				}
				
				$target = 'content/img/'.$date.'/'. $rand . basename($_FILES['photo']['name']);
				move_uploaded_file($_FILES['photo']['tmp_name'], $target);

				$e .= "<p>Слика је успешно послата и налази се овде: ".ROOT.$target."</p>";	
			}
		}
	}
}

$s .= 
"
<p class='green'>Све слике су овде: <a href='".ROOT."content/img/'>".ROOT."content/img/</a></p>
$e
<form action='' method='post' enctype='multipart/form-data'>
	Ваша слика: &nbsp; <input type='file' name='photo' size='25'>
	<input type='submit' name='submit' class='but1' value='Пошаљи'>
</form>
";

$cont =
"
<div id='cont'>
<h1>Слике</h1>
$s
</div>
";

?>