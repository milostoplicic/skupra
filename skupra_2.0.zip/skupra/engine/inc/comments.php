<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s = '';

$link = new DB();

if (isset($_POST['submit'])) {

	$comid = $_POST['comid'];

	if (!empty($comid)) {
		
		$query = "UPDATE comments SET pub = 1 WHERE comid = ?";
		$result = $link->UpdateRow($query, [$comid]);
		
		$s .= "<p class='green'>Коментар је објављен!</p>";
	}
}

if (isset($_POST['submit1'])) {

	$comid = $_POST['comid'];

	if (!empty($comid)) {
		
		$query = "UPDATE comments SET pub = 0 WHERE comid = ?";
		$result = $link->UpdateRow($query, [$comid]);

		$s .= "<p class='red'>Коментар је уклоњен!</p>";
	}
}

if (isset($_POST['submit2'])) {

	$comid = $_POST['comid'];

	if (!empty($comid)) {
		
		$query = "DELETE FROM comments WHERE comid = ?";
		$result = $link->UpdateRow($query, [$comid]);

		$s .= "<p class='red'>Коментар је избрисан!</p>";
	}
}

$query1 = "SELECT COUNT(*) FROM comments";
$count = $link->GetRow($query1);

$total = ($count['COUNT(*)']);

if ($total > 0) {
	
	$limit = 30;
	$page = (C2 != '') ? C2 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);
	
	$query = "SELECT * FROM comments ORDER BY comid DESC LIMIT $start, $limit";
	$result = $link->GetRows($query);

	foreach ($result as $r) {
		
		if ($r['pub'] == 0) {

			$e = "<span class='red'>Коментар није приказан!</span>";
		} else {

			$e = "<span class='green'>Коментар је приказан!</span>";
		}

		$s.= "<p><b>$r[comid]</b> | <b>$r[name]</b><br>$r[comment] | $e</p>";
	}
	
	$s .=
	"
	<form action='' method='post'>
	Унеси ИД број коментара који желите да буде видљив.<br><br>
	ИД: <input type='text' name='comid' class='fil4'>
	<input type='submit' name='submit' class='but1' value='Објави'>
	</form>
	<br>
	<form action='' method='post'>
	Унеси ИД број коментара који желите да склоните.<br><br>
	ИД: <input type='text' name='comid' class='fil4'>
	<input type='submit' name='submit1' class='but1' value='Уклони'>
	</form>
	<div class='line'></div>
	<h2>Избриши коментар</h2>
	<form action='' method='post'>
	Унеси ИД број коментара који желите да избришете.<br><br>
	ИД: <input type='text' name='comid' class='fil4'>
	<input type='submit' name='submit2' class='but1' value='Избриши'>
	</form>
	";

	$s .= Engine::Pagination($page, $num_page, 'komentari');
} else {

	$s = "<p class='red'>Нема коментара!</p>";
}

$cont =
"
<div id='cont'>
<h1>Коментари</h1>
$s
</div>
";

?>