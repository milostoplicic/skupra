-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 30, 2020 at 12:20 PM
-- Server version: 5.7.29-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skupra`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `artid` int(11) NOT NULL,
  `header` varchar(128) NOT NULL,
  `seo` varchar(128) NOT NULL,
  `date` date NOT NULL,
  `tekst` text NOT NULL,
  `catid` int(11) NOT NULL,
  `pregledi` int(11) NOT NULL,
  `authorid` int(11) NOT NULL,
  `minview` int(11) NOT NULL DEFAULT '400',
  `comments` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`artid`, `header`, `seo`, `date`, `tekst`, `catid`, `pregledi`, `authorid`, `minview`, `comments`) VALUES
(5, 'Манифест', 'manifest', '2020-02-22', '<p style=\"text-align: justify;\">Поштовани народе,</p>\r\n<p style=\"text-align: justify;\">Сила приморала, а неправда уздигла, док Бог подари зрно мудрости, па се осилих да вам пишем онако како ја умем. Ја имам карактеристичну црту да не завршавам ствари које сам започео. Морате знати и зашто. Зато што уживам док стварам и при томе увек нешто ново научим. И сад уместо да то научено делим другима, ја то поново применим од свог почетка. Тако да све стане некако на пола.</p>\r\n<p style=\"text-align: justify;\">Али, ако Бог помогне и мене здравље послужи, довршићу овај свој пројекат. Само једно да знате. Не мења човек свест преко ноћи, не мења карактер преким инаћењем. Мора човек да пусти да се ствари одвијају и он да се уклопи у то.</p>\r\n<p style=\"text-align: justify;\">Искрено верујем да ће овај пројекат надживети свог креатора, тј. мене. И искрено се надам да нећу никад морати јавно да се ангажујем да бих анимирао људе да ме следе. Нек свако следи свој корак, па срешћемо се.</p>\r\n<p style=\"text-align: justify;\">Шта значи <strong>Скупра</strong>?</p>\r\n<p style=\"text-align: justify;\">У преводу \"Скуп\" и \"РА\".</p>\r\n<p style=\"text-align: justify;\"><strong>\"Скуп\"</strong> је митинг, заједништво, група појединаца или неких елемената.</p>\r\n<p style=\"text-align: justify;\"><strong>\"РА\"</strong> је Бог Сунца по Египатској митологији. И како научници тврде, најстарија монументална ризница богообожавања. Тј. најстарија монотеистичка религија.</p>\r\n<p style=\"text-align: justify;\">Оно што желим од вас, то је да ме читате и да верујете како можете нешто ново научити, а ја верујем да можете. Бар колико и ја знам.</p>\r\n<p style=\"text-align: justify;\">Моја интересовања су многострука, куда ће нас овај пут заједно одвести, зна само Бог. Па онда да се препустимо. Идемо !!!</p>', 1, 21, 1, 400, 1),
(6, 'Кад ће бити боље?', 'kad-ce-biti-bolje-22-02-2020', '2020-02-22', '<p>Како сам старији све ми је теже да поверујем, како некада може бити боље. Не може. Може бити само забавније или тужније. Боље, никад.<br /><br /><strong>Јер шта значи бити боље? Који су параметри?</strong><br /><br />Неки од основних, јесу: да је живот лакши, да се лепше живи, да постоји мотивација и срећа. А то с годинама опада, постајемо старији, зрелији, мудрији, плашљивији и болеснији. Зато кад вам неко каже, <strong>биће боље</strong>, знајте одмах да вас лаже. Некад случајно, некад намерно. Политичари то раде намерно. Јер то је једино за шта може да се ухвате. Да обећају нешто.</p>\r\n<p style=\"text-align: justify;\"><strong>Шта је са парама?</strong><br /><br />Мене страшно боли ова глобална неправда, а то је да је богатих и сиромашних све више. А то је доказ да су огромне класне разлике, па да се у будућности неко не зачуди, ако поново завлада робовласничко друштво.<br />То су страшне ствари. Ми једни другима нисмо потребни као бића, већ само као машине које ће нешто да одраде или да заврше. А то тлачење врше пре свега богати.<br /><br />Да се не лажемо, новац је данас најбитнији на свету. Ко има новац има све. А најјебозовније је то што тај исти богаташ каже, како му паре нису важне.<br /><br />Замислите ви ту окрутност, дебилизам, идиотизам и бескрупулозност. Најпосећеније мотивационе скупове и говоре држе управо најбогатији људи света. И они вам никада неће открити како су се заиста обогатили, већ ће да вам замазују очи, шареним причама о труду, раду, неспавању, борби.<br /><br /><strong>Не друшкане</strong>, није то ништа тако. Да будеш богат треба само да имаш јебозовну срећу. То је прво. Друго је да будеш окрутан. Треће је да те боли дупе за друге и четврто је ако можеш да газиш по лешевима.<br /><br />Отишао је овај свет у курац, ја да вам кажем. Али...<br /><br />Имате два пута, или да прогутате плаву пилулу и прихватити ризике и ухватити се у коштац и борити се. Или прогутати црвену пилулу па се борити против ветрењача.<br /><br />Сви знамо да је боља плава пилула. За кога? За онога ко те гледа са стране и мери твој успех. За тебе је та плава пилула курац и не значи ти ништа.<br /><br />Црвена пилула је закон. Е то је права борба и револуција. Када прокључа вода. И у њу ставимо сва та говна која нам скачу по главама. <strong>Како?</strong><br /><br />Ево ја сам направио први корак. За почетак знамо куда идемо. Против власти, против богаташа, тајкуна, трговинских ланаца и осталих медијских јахташа и болесника.<br /><br />Ја сам се због њих и разболео. Јер сам деценијама гледао неправду коју нам дају. Доста је било. <strong>На вешала !!!</strong></p>', 1, 8, 1, 200, 0),
(7, 'Фашизам да-не?', 'fasizam-da-ne-22-02-2020', '2020-02-22', '<p style=\"text-align: justify;\">Да вам кажем једну ствар. Овај сајт је требао да буде <strong>фашистички са свастиком као логотипом</strong>. Међутим, не бих да се повезујем са том идеологијом јер је још увек пуно нејасноћа.<br /><br />Нешто је било добро, нешто није. Сама идеја је била добра. Али су је проводили буздовани. Зато је тај рат изгубљен. Али не бих сада о томе.</p>', 3, 12, 1, 400, 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `catid` int(11) NOT NULL,
  `catname` varchar(64) NOT NULL,
  `catseo` varchar(64) NOT NULL,
  `catdesc` text NOT NULL,
  `image` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`catid`, `catname`, `catseo`, `catdesc`, `image`) VALUES
(1, 'Основна категорија', 'osnovna-kategorija', 'Опште теме. Главни садржаји. Свакодневица. Све на једном месту, што није категорисано.', ''),
(3, 'Кратке смернице', 'kratke-smernice', 'Ово је категорија за кратке мисли и упуте.', '');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `comment` varchar(256) NOT NULL,
  `artid` int(11) NOT NULL,
  `cdate` datetime NOT NULL,
  `pub` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(64) NOT NULL,
  `session` varchar(32) NOT NULL,
  `usertype` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `password`, `email`, `session`, `usertype`) VALUES
(1, 'admin', '1234', 'milostoplicic@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 1),
(2, 'moderator', '1234', '', 'bcbe3365e6ac95ea2c0343a2395834dd', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`artid`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `artid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `catid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
