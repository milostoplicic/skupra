<?php

if (!defined('PROTECT')){die('Protected Content!');}

// cookie name
define('SITE', 'skupra');

// This is the folder on the hosting, if it is root, leave only a slash. The folder is "skupra" to me and that's why it says so
define('ROOT', '/skupra/');

// Address site
define('URL', 'https://skupra.com/');

// default language = "eng" or "lat" or "cyr"
define('DFLANG', 'cyr');

// compression 1 or 0
define('COMPRESS', 0);

// homepage
define('HOME', 'intro');

// Title on browser
define('TITLE', '::SkupRa');

// favicon
define('FAVICON', ROOT.'look/img/favicon-skupra.png');

// default css style
define('STYLE', ROOT.'look/css/style.css');

// database
define('HOST', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DBNAME', 'skupra');

// email for contact
define('EMAIL', 'office@skupra.com');

function Path() {

	$path = isset($_GET['path']) ? $_GET['path'] : '';
	$path = explode ('/', $path);

	return $path;
}

$path = Path();

if ($path[0] == 'eng') {

	define('LANG', 'eng');
} else if ($path[0] == 'cyr') {

	define('LANG', 'cyr');
} else if ($path[0] == 'lat') {
	
	define('LANG', 'lat');
} else {
	
	define('LANG', DFLANG);
}

define('C1', isset($path[1]) ? $path[1] : '');
define('C2', isset($path[2]) ? $path[2] : '');
define('C3', isset($path[3]) ? $path[3] : '');
define('C4', isset($path[4]) ? $path[4] : '');

?>