// UPUTSTVO //

1. Napraviti bazu poželjno je da se zove "skupra". Zatim importovati sadržaj u nju.

2. mod_rewrite mora biti uključen

3. Pišite tekstove

4. Ako želite modifikacije, sva podešavanja su u "config.php" i "lang" folderu

5. Čitajte kod. Učite.

6. Skoro svaki folder sadrži fajl ".htaccess", i on mora biti kopiran. Ako ste na linuxu extra.


##################################################

// INSTRUCTIONS //

1. To make a base it is desirable to call it "skupra". Then import the content into it.

2. mod_rewrite must be turned on

3. Write texts

4. If you want modifications, all settings are in the "config.php" and "lang" folders

5. Read the code. Learn.

6. Almost every folder contains a ".htaccess" file, and it must be copied. If you are on linux extra.