<?php

if (!defined('PROTECT')){die('Protected Content!');}

$c = array(

	'html_lang'		=> 'sr',
	'charset'		=> 'utf-8',
	'description'	=> 'Моје луде мисли.',
	'keywords'		=> 'web, интернет, блог, милош, развој',
	'author'		=> 'Милош Топличић',
	//
	'blog'			=> 'блог',
	'categories'	=> 'категорије',
	'archive'		=> 'архива',
	'manifest'		=> 'манифест',
	'contact'		=> 'контакт',
	'signin'		=> 'пријава',
	'signout'		=> 'одјава',
	'write'			=> 'напиши чланак',
	'edit'			=> 'едитуј чланак',
	'delete'		=> 'избриши чланак',
	'images'		=> 'слике',
	'addc'			=> 'додај категорију',
	'editc'			=> 'едитуј категорију',
	'deletec'		=> 'избриши категорију',
	'comments'		=> 'коментари'
);

?>