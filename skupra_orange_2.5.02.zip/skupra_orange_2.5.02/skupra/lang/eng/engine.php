<?php

if (!defined('PROTECT')){die('Protected Content!');}

$c = array(

	'nouser'			=> 'There is no such user!',
	'nevem'				=> 'Invalid email format!',
	'promese'			=> 'Change the title. That (SEO) already exists!',
	'prose'				=> 'Change SEO. That one already exists!',
	'catex'				=> 'That category already exists!',
	'catexe'			=> 'That category name already exists! Choose another.',
	'nocat'				=> 'There is no such category!',
	'noauthor'			=> 'There is no such author!'
);

?>