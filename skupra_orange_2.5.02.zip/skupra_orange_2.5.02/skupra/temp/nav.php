<?php

if (!defined('PROTECT')){die('Protected Content!');}

$nav = 
"
<nav>
	<ul>
	<li><a href='".ROOT.LANG.'/intro'."'>$c[intro]</a></li>
	  <li><a $b href='".ROOT.LANG."/blog'>$c[blog]</a></li>
	  <li><a $k href='".ROOT.LANG."/kategorije'>$c[categories]</a></li>
	  <li><a $a href='".ROOT.LANG."/arhiva'>$c[archive]</a></li>
	  <li><a $m href='".ROOT.LANG."/manifest'>$c[manifest]</a></li>
	  	  <li><a $ko href='".ROOT.LANG."/kontakt'>$c[contact]</a></li>
	  <li class='dropdown'>
		<a href='#' class='dropbtn'>$c[lang]</a>
		<div class='dropdown-content'>
			<a href='".ROOT."eng/".$c1.$c2.$c3.$c4."'>$c[eng]</a>
			<a href='".ROOT."cyr/".$c1.$c2.$c3.$c4."'>$c[cyr]</a>
			<a href='".ROOT."lat/".$c1.$c2.$c3.$c4."'>$c[lat]</a>
		</div>
	  </li>
	</ul>
</nav>
";

?>