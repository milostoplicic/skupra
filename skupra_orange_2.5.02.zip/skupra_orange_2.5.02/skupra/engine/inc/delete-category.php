<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (isset($_POST['submit'])) {
	
	$catid = $_POST['catid'];
	
	$link = new DB();
	$query1 = "SELECT * FROM articles WHERE catid = ?";
	$result1 = $link->GetRows($query1, [$catid]);
	
	if ($result1) {
		
		$e = "<p class='red'>$c[tacni]</p>";
	} else {
		
		$query = "DELETE FROM categories WHERE catid = ?";
		$result = $link->DeleteRow($query, [$catid]);
		
		if ($result) {
			
			header('Location: '.ROOT.LANG.'/info/category-delete-success');
		} else {
			
			$e = "<p class='red'>$c[nocat]</p>";
		}
	}
}

$s = '';

$link = new DB();
	
$query1 = "SELECT COUNT(*) FROM categories";
$count = $link->GetRow($query1);

$total = ($count['COUNT(*)']);

if ($total > 0) {
	
	$limit = 30;
	$page = (C2 != '') ? C2 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);

	$query = "SELECT * FROM categories ORDER BY catid DESC LIMIT $start, $limit";
	$result = $link->GetRows($query);

	foreach ($result as $r) {
		
		$s .= "<p><b>$r[catid]</b> | $r[catname] | $r[catseo]</p>";
	}

	$s .=
	"
	<form action='' method='post'>
	$c[idcatiz]<br><br>
	ИД: <input type='text' name='catid' class='fil4'>
	<input type='submit' name='submit' class='but1' value='$c[izb]'>
	</form>
	";

	$s .= Engine::Pagination($page, $num_page, 'izbrisi-kategoriju');
} else {
	
	$s = "<p class='red'>$c[nocat2]</p>";
}

$cont =
"
<div id='cont'>
<h1>$c[izbcat]</h1>
<p class='green'>$c[mocatsa]</p>
$e
$s
</div>
";

?>