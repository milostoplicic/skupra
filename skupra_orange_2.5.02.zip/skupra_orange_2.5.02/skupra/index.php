<?php

// protection against loading individual files
define('PROTECT', 'skupra');

// errors
ini_set('display_errors', 1);
error_reporting(E_ALL);

// session start
// buffer start
session_start();
ob_start();

// base config file
require_once 'config.php';

// database
require_once 'engine/DB.class.php';

// initialization
require_once 'engine/Init.class.php';

// content
require_once 'engine/Content.class.php';

// decode
require_once 'engine/Decode.class.php';

// engine
require_once 'engine/Engine.class.php';

$init = new Init;
$init->Start();

$content = new Content();

$decode = new Decode;
echo $decode->Output();

?>