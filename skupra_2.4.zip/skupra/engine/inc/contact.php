<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (isset($_POST['submit'])) {
	
	$email = $_POST['email'];
	$message = $_POST['message'];
	
	if (empty($email) OR empty($message)) {
		
		$e = "<p class='red'>Попуните обавезна поља!</p>";
	} else {
		
		$e = Engine::Contact($email, $message);
	}
}

$cont =
"
<div id='cont'>
<h1>Контакт</h1>
$e
<form action='' method='post'>
Ваша е-пошта (e-mail)(*):<br>
<input type='text' name='email' maxlength='64' placeholder='Е-пошта' class='fil3'><br><br>
Порука(*):<br>
<textarea class='fil2' name='message' maxlength='200' placeholder='Порука (200 карактера)'></textarea><br><br>
<input type='submit' name='submit' class='but1' value='Пошаљи'>
</form>
</div>
";

?>