<?php

if (!defined('PROTECT')){die('Protected Content!');}

if (USERTYPE == 0) {
	
	$sig = "Ауторско Право <b>&copy;</b> 2019, 2020 Скупра &nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/prijavi-se'>Пријави се</a>";
} else {
	
	$sig = 
	"
	Ауторско Право <b>&copy;</b> 2019, 2020 Скупра<br><br>
	".$_SESSION[SITE]['username']."
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/odjavi-se'>Одјави се</a>
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/pisi'>Пиши</a>
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/edituj'>Едитуј</a>
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/izbrisi'>Избриши</a>
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/slike'>Слике</a>
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/dodaj-kategoriju'>Додај категорију</a>
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/edituj-kategoriju'>Едитуј категорију</a>
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/izbrisi-kategoriju'>Избриши категорију</a>
	&nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/komentari'>Коментари</a>
	";
}

$footer =
"
<div id='footer'>
$sig
</div>
";

?>