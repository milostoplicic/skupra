<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s1 = rand(0, 10);
$s2 = rand(0, 10);
$s3 = md5($s1 + $s2);

$s = '';
$e = '';
$comme = '';

if (C2 != '') {
	
	$link = new DB();
	
	if (!isset($_SESSION[SITE][C2])) {
		
		$query1 = "UPDATE articles SET pregledi = pregledi + 1 WHERE seo = ?";
		$result1 = $link->UpdateRow($query1, [C2]);
	
		$_SESSION[SITE][C2] = 1;
	}
	
	$query = "SELECT * FROM articles WHERE seo = ?";
	$result = $link->GetRow($query, [C2]);
	
	if ($result) {
		
		if ($result['comments'] == 0) {
			
			$co = ' | Коментари искључени';
			$coform = '';
		} else {

			$queryc = "SELECT COUNT(*) FROM comments WHERE artid = ? AND pub = 1";
			$resultc = $link->GetRow($queryc, [$result['artid']]);

			$tot = $resultc['COUNT(*)'];

			$co = ' | Коментари: '. "<b>".$tot."</b>";

			if (isset($_POST['submit'])) {

				$name = $_POST['name'];
				$message = $_POST['message'];

				if (md5($_POST['s3']) == $_POST['s3check']) {

					if (empty($name) AND empty($message)) {

						$e = "<p class='red'>Попуните обавезна поља!</p>";
					} else {
						
						$cdate = date("Y-m-d H:i:s");
						
						$queryu = "INSERT INTO comments(name, comment, artid, cdate, pub) VALUES(?, ?, ?, ?, ?)";
						$resultu = $link->InsertRow($queryu, [$name, $message, $result['artid'], $cdate, 0]);

						$e = "<p class='green'>Коментар је послат на администрацију!</p>";
					}
				} else {

					$e = "<p class='red'>Погрешан резултат!</p>";
				}
			}

			$queryco = "SELECT * FROM comments WHERE artid = ? AND pub = 1 ORDER BY comid DESC";
			$resultco = $link->GetRows($queryco, [$result['artid']]);
			
			if ($resultco) {
				
				foreach ($resultco as $rc) {

					$datum = explode(' ', $rc['cdate']);
					$datum1 = explode('-', $datum[0]);
					$datum2 = $datum1[2].'.'.$datum1[1].'.'.$datum1[0];

					$time = $datum[1];

					$comme .=
					"
					<p>Име: <b>$rc[name]</b> | Датум: <b>".$datum2."</b>".' | Време: <b>'.$time."</b></p>
					<p>$rc[comment]</p>
					<div class='line'></div>
					";	
				}
			} else {

				$comme = "<p class='red'>Нема коментара!</p>";
			}

			$coform = 
			"
				<br>
				<div class='line'></div>
				<h2>Унеси коментар</h2>
				<form action='' method='post'>
					Име(*):<br>
					<input type='text' name='name' maxlength='20' placeholder='Ваше име' class='fil3'><br><br>
					Порука(*):<br>
					<textarea class='fil2' name='message' maxlength='200' placeholder='Порука (200 карактера)'></textarea><br><br>
					Израчунај: $s1 плус $s2 = <input type='text' name='s3' class='fil4'><br><br>
					<input type='hidden' value='$s3' name='s3check'>
					<input type='submit' name='submit' class='but1' value='Пошаљи'>
				</form>
				<br>
				<div class='line'></div>
				<h2>Коментари</h2>
				$comme
			";
		}

		$date = explode('-', $result['date']);
		$date = $date[2].'.'.$date[1].'.'.$date[0];
		
		$cat = Engine::CatName($result['catid']);

		$catseo = Engine::CatSeo($result['catid']);
		
		$author = Engine::Author($result['authorid']);
		
		$s .=
		"
		<h2>$result[header]</h2>
		<p class='date'>Датум: <b>$date</b> | Категорија: <a href='".ROOT.LANG."/kategorija/".$catseo."'><b>$cat</b></a> | Аутор: <a href='".ROOT.LANG."/clanci-od-korisnika/".$author."'><b>$author</b></a> | Прегледи: <b>$result[pregledi]</b>$co</p>
		$result[tekst]
		$coform
		";
	} else {
		
		$s = "<p>No content!</p>";
	}
} else {
	
	$s = "<p>No content!</p>";
}

$cont =
"
<div id='cont'>
$e
$s
</div>
";

?>