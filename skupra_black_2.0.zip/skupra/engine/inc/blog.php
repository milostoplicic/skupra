<?php

if (!defined('PROTECT')){die('Protected Content!');}

if (isset($_POST['poredak'])) {
	
	if ($_POST['poredak'] == 1) {

		$po = "<b>по датуму</b>";
		$p = 'artid';
	} else if ($_POST['poredak'] == 2) {

		$po = "<b>по прегледима</b>";
		$p = 'pregledi';
	} else {

		$po = "<b>по датуму</b>";
		$p = 'artid';
	}
} else {

	$po = "<b>по датуму</b>";
	$p = 'artid';
}

$s =
"
<form method='post'>
    <select name='poredak' onchange='if(this.value != 0) { this.form.submit(); }'>
         <option value='0'>Поредак</option>
         <option value='1'>по датуму</option>
         <option value='2'>по прегледима</option>
    </select>&nbsp;&nbsp;$po
</form>
";

$link = new DB();
	
$query1 = "SELECT COUNT(*) FROM articles";
$count = $link->GetRow($query1);

$total = ($count['COUNT(*)']);

if ($total > 0) {
	
	$limit = 30;
	$page = (C2 != '') ? C2 : 1;
	$start = $limit * ($page-1);
	$num_page = ceil($total/$limit);
	
	$query = "SELECT * FROM articles ORDER BY $p DESC LIMIT $start, $limit";
	$result = $link->GetRows($query);

	foreach ($result as $r) {
		
		if ($r['comments'] == 0) {
			
			$co = ' | Коментари искључени';
		} else {

			$queryc = "SELECT COUNT(*) FROM comments WHERE artid = ? AND pub = 1";
			$resultc = $link->GetRow($queryc, [$r['artid']]);

			$tot = $resultc['COUNT(*)'];

			$co = ' | Коментари: '. "<b>".$tot."</b>";
		}

		$date = explode('-', $r['date']);
		$date = $date[2].'.'.$date[1].'.'.$date[0];
		
		$string = mb_substr(strip_tags($r['tekst'], '<img>'), 0, $r['minview'], 'utf-8');
		
		$cat = Engine::CatName($r['catid']);

		$catseo = Engine::CatSeo($r['catid']);
		
		$author = Engine::Author($r['authorid']);
		
		$s .= 
		"
		<h2><a href='".ROOT.LANG."/clanak/".$r['seo']."'>$r[header]</a></h2>
		<p class='date'>Датум: <b>$date</b> | Категорија: <a href='".ROOT.LANG."/kategorija/".$catseo."'><b>$cat</b></a> | Аутор: <a href='".ROOT.LANG."/clanci-od-korisnika/".$author."'><b>$author</b></a> | Прегледи: <b>$r[pregledi]</b>$co</p>
		<p>".$string." ... <a href='".ROOT.LANG."/clanak/".$r['seo']."'>Прочитај више</a></p>
		<div class='line'></div>
		";
	}
	
	$s .= Engine::Pagination($page, $num_page, 'blog');
} else {
	
	$s = "<p class='red'>Нема чланака!</p>";
}

$cont =
"
<div id='cont'>
<h1>Блог</h1>
$s
</div>
";

?>