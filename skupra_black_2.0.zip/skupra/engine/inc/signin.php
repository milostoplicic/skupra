<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (isset($_POST['submit'])) {
	
	$username = $_POST['username'];
	$password = $_POST['password'];
	$remember = isset($_POST['remember']) ? 1 : 0;
	
	if (empty($username) OR empty($password)) {
		
		$e = "<p class='red'>Попуните обавезна поља!</p>";
	} else {
		
		$e = Engine::Signin($username, $password, $remember);
	}
}

$cont =
"
<div id='cont'>
<h1>Пријави се</h1>
$e
<form action='' method='post'>
Корисничко име(*):<br> 
<input type='text' name='username' placeholder='Корисничко име' maxlength='20' class='fil1'><br><br>
Лозинка(*):<br>
<input type='password' name='password' placeholder='Лозинка' maxlength='20' class='fil1'><br><br>
Запамти ме <input type='checkbox' name='remember' checked>
<input type='submit' name='submit' class='but1' value='Прихвати'>
</form>
</div>
";

?>